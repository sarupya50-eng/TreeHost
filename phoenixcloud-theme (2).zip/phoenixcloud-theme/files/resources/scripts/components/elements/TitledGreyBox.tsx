import React, { memo } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IconProp } from '@fortawesome/fontawesome-svg-core';
import tw from 'twin.macro';
import isEqual from 'react-fast-compare';

interface Props {
    icon?: IconProp;
    title: string | React.ReactNode;
    className?: string;
    children: React.ReactNode;
}

const TitledGreyBox = ({ icon, title, children, className }: Props) => (
    <div css={tw`rounded-xl shadow-lg bg-neutral-700 border border-neutral-600 overflow-hidden`} className={className}>
        <div css={tw`bg-neutral-900 p-3 border-b border-neutral-600`}>
            {typeof title === 'string' ? (
                <p css={tw`text-sm uppercase tracking-wider`}>
                    {icon && <FontAwesomeIcon icon={icon} css={tw`mr-2 text-sky-300`} />}
                    {title}
                </p>
            ) : (
                title
            )}
        </div>
        <div css={tw`p-3`}>{children}</div>
    </div>
);

export default memo(TitledGreyBox, isEqual);
