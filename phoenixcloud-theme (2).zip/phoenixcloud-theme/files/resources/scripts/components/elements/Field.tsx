import React, { forwardRef, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IconDefinition, faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';
import { Field as FormikField, FieldProps } from 'formik';
import Input from '@/components/elements/Input';
import Label from '@/components/elements/Label';

interface OwnProps {
    name: string;
    light?: boolean;
    label?: string;
    description?: string;
    // Optional icon drawn inside the left edge of the input.
    icon?: IconDefinition;
    // For password inputs: adds a show/hide toggle.
    reveal?: boolean;
    validate?: (value: any) => undefined | string | Promise<any>;
}

type Props = OwnProps & Omit<React.InputHTMLAttributes<HTMLInputElement>, 'name'>;

const Field = forwardRef<HTMLInputElement, Props>(
    ({ id, name, light = false, label, description, icon, reveal, validate, ...props }, ref) => {
        const [shown, setShown] = useState(false);

        return (
            <FormikField innerRef={ref} name={name} validate={validate}>
                {({ field, form: { errors, touched } }: FieldProps) => (
                    <div>
                        {label && (
                            <Label htmlFor={id} isLight={light}>
                                {label}
                            </Label>
                        )}
                        <div className={'relative'}>
                            {icon && (
                                <FontAwesomeIcon
                                    icon={icon}
                                    className={'absolute left-4 top-1/2 -mt-2 text-neutral-400 pointer-events-none'}
                                />
                            )}
                            <Input
                                id={id}
                                {...field}
                                {...props}
                                type={reveal && shown ? 'text' : props.type}
                                style={{
                                    paddingLeft: icon ? '2.75rem' : undefined,
                                    paddingRight: reveal ? '2.75rem' : undefined,
                                }}
                                isLight={light}
                                hasError={!!(touched[field.name] && errors[field.name])}
                            />
                            {reveal && (
                                <button
                                    type={'button'}
                                    tabIndex={-1}
                                    onClick={() => setShown((v) => !v)}
                                    className={'absolute right-4 top-1/2 -mt-2 text-neutral-400 hover:text-sky-300'}
                                >
                                    <FontAwesomeIcon icon={shown ? faEyeSlash : faEye} />
                                </button>
                            )}
                        </div>
                        {touched[field.name] && errors[field.name] ? (
                            <p className={'input-help error'}>
                                {(errors[field.name] as string).charAt(0).toUpperCase() +
                                    (errors[field.name] as string).slice(1)}
                            </p>
                        ) : description ? (
                            <p className={'input-help'}>{description}</p>
                        ) : null}
                    </div>
                )}
            </FormikField>
        );
    }
);
Field.displayName = 'Field';

export default Field;
