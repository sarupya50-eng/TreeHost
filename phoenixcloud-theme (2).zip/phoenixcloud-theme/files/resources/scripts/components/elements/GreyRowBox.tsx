import styled from 'styled-components/macro';
import tw from 'twin.macro';

export default styled.div<{ $hoverable?: boolean }>`
    ${tw`flex rounded-xl no-underline text-neutral-200 items-center p-4 border border-neutral-600 transition-all duration-200 overflow-hidden`};

    background: linear-gradient(160deg, #18181b, #0e0e10);
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.04);
    backdrop-filter: blur(6px);

    ${(props) => props.$hoverable !== false && tw`hover:border-sky-400`};
    transition: transform 0.25s cubic-bezier(0.22, 1, 0.36, 1), border-color 0.25s ease, box-shadow 0.25s ease;
    &:hover { transform: translateY(-2px); box-shadow: 0 14px 30px -14px #000; }

    & .icon {
        ${tw`rounded-full w-16 flex items-center justify-center p-3 text-sky-300`};
        background: rgba(56, 189, 248, 0.12);
    }
`;
