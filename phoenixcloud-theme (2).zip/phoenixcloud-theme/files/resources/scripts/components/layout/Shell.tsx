import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    IconDefinition,
    faBars,
    faChevronDown,
    faComments,
    faCreditCard,
    faGlobe,
    faLifeRing,
    faSearch,
    faSignOutAlt,
    faTimes,
} from '@fortawesome/free-solid-svg-icons';
import { useStoreState } from 'easy-peasy';
import http from '@/api/http';
import Avatar from '@/components/Avatar';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import SearchModal from '@/components/dashboard/search/SearchModal';
import useEventListener from '@/plugins/useEventListener';
import phoenix from '@/phoenix.config';

// Icon for each configured quick link (matched by title).
export const linkIcon = (title: string): IconDefinition =>
    /discord/i.test(title)
        ? faComments
        : /billing/i.test(title)
        ? faCreditCard
        : /support/i.test(title)
        ? faLifeRing
        : faGlobe;

interface SideLinkProps {
    to: string;
    label: string;
    icon: IconDefinition;
    exact?: boolean;
    external?: boolean;
}

// A single entry in the sidebar. Rendered as a plain anchor for external (non-SPA) links such as /admin.
export const SideLink = ({ to, label, icon, exact, external }: SideLinkProps) => {
    const cls =
        'group flex items-center gap-3 px-3 py-2 my-0.5 rounded-lg text-sm text-neutral-300 no-underline border border-transparent transition-all duration-150 hover:text-sky-200 hover:bg-neutral-700';
    const inner = (
        <>
            <FontAwesomeIcon icon={icon} fixedWidth className={'text-neutral-400 group-hover:text-sky-300'} />
            <span>{label}</span>
        </>
    );

    return external ? (
        <a href={to} className={cls} rel={'noreferrer'}>
            {inner}
        </a>
    ) : (
        <NavLink to={to} exact={exact} className={cls} activeClassName={'pc-side-active'}>
            {inner}
        </NavLink>
    );
};

export const SideHeading = ({ children }: { children: React.ReactNode }) => (
    <p className={'px-3 mt-5 mb-1 text-2xs font-semibold uppercase tracking-widest text-neutral-400'}>{children}</p>
);

// Collapsible sidebar section with a smooth height/opacity transition.
export const SideGroup = ({
    title,
    children,
    defaultOpen = true,
}: {
    title: string;
    children: React.ReactNode;
    defaultOpen?: boolean;
}) => {
    const [open, setOpen] = useState(defaultOpen);

    return (
        <div>
            <button
                type={'button'}
                onClick={() => setOpen((o) => !o)}
                className={
                    'flex w-full items-center justify-between px-3 mt-5 mb-1 text-2xs font-semibold uppercase tracking-widest text-neutral-400 hover:text-neutral-200'
                }
            >
                {title}
                <FontAwesomeIcon
                    icon={faChevronDown}
                    className={`transition-transform duration-200 ${open ? '' : '-rotate-90'}`}
                />
            </button>
            <div
                className={`overflow-hidden transition-all duration-300 ease-out ${
                    open ? 'max-h-[700px] opacity-100' : 'max-h-0 opacity-0'
                }`}
            >
                {children}
            </div>
        </div>
    );
};

interface ShellProps {
    // Sidebar entries rendered under the logo.
    nav?: React.ReactNode;
    // Optional block between the logo and the nav (used for the server summary).
    header?: React.ReactNode;
    children: React.ReactNode;
}

export default ({ nav, header, children }: ShellProps) => {
    const name = useStoreState((state) => state.settings.data!.name);
    const user = useStoreState((state) => state.user.data!);
    const [open, setOpen] = useState(false);
    const [searching, setSearching] = useState(false);
    const [loggingOut, setLoggingOut] = useState(false);
    const [supportOpen, setSupportOpen] = useState(false);
    const links = phoenix.links.filter((l) => l.url);

    useEventListener('keydown', (e: KeyboardEvent) => {
        if (['input', 'textarea'].indexOf(((e.target as HTMLElement).tagName || 'input').toLowerCase()) < 0) {
            if (!searching && e.metaKey && e.key.toLowerCase() === '/') setSearching(true);
        }
    });

    const logout = () => {
        setLoggingOut(true);
        http.post('/auth/logout').finally(() => {
            // @ts-expect-error this is valid
            window.location = '/';
        });
    };

    return (
        <div className={'min-h-screen md:flex'}>
            <div className={'pc-bg'} />
            <SpinnerOverlay visible={loggingOut} />
            {searching && <SearchModal appear visible={searching} onDismissed={() => setSearching(false)} />}

            {open && (
                <div className={'fixed inset-0 z-30 bg-black bg-opacity-60 md:hidden'} onClick={() => setOpen(false)} />
            )}

            <aside
                className={`fixed inset-y-0 left-0 z-40 w-64 flex flex-col bg-neutral-900 border-r border-neutral-600 transform transition-transform duration-200 md:sticky md:top-0 md:h-screen md:translate-x-0 ${
                    open ? 'translate-x-0' : '-translate-x-full'
                }`}
            >
                <div className={'flex items-center justify-between px-4 h-16 flex-none'}>
                    <Link to={'/'} className={'flex items-center no-underline'}>
                        <img src={'/assets/phoenixcloud-logo.png'} alt={''} className={'h-9 w-9 mr-3 rounded-lg'} />
                        <span className={'text-xl font-header font-semibold text-neutral-100 tracking-wide'}>
                            {name}
                        </span>
                    </Link>
                    <button className={'md:hidden text-neutral-300'} onClick={() => setOpen(false)}>
                        <FontAwesomeIcon icon={faTimes} />
                    </button>
                </div>

                <div className={'flex-1 overflow-y-auto px-3 pb-4'} onClick={() => setOpen(false)}>
                    {header}
                    {nav}
                </div>

                <div className={'flex-none flex items-center gap-3 px-4 py-3 border-t border-neutral-600'}>
                    <Link to={'/account'} className={'flex items-center flex-1 min-w-0 no-underline'}>
                        <span className={'flex w-8 h-8 flex-none'}>
                            <Avatar.User />
                        </span>
                        <span className={'ml-3 text-sm text-neutral-200 truncate'}>{user.username}</span>
                    </Link>
                    <button
                        onClick={logout}
                        title={'Sign out'}
                        className={'text-neutral-300 hover:text-red-400 transition-colors duration-150'}
                    >
                        <FontAwesomeIcon icon={faSignOutAlt} />
                    </button>
                </div>
            </aside>

            <div className={'flex-1 min-w-0 px-0 md:px-4 lg:px-6'}>
                <div className={'flex items-center gap-3 px-4 pt-4 md:pt-6 max-w-[1200px] mx-auto'}>
                    <button
                        className={
                            'md:hidden flex-none w-10 h-10 rounded-lg border border-neutral-600 bg-neutral-700 text-neutral-200'
                        }
                        onClick={() => setOpen(true)}
                    >
                        <FontAwesomeIcon icon={faBars} />
                    </button>
                    <button
                        onClick={() => setSearching(true)}
                        className={
                            'flex items-center flex-1 sm:flex-none sm:w-80 h-10 px-4 rounded-full border border-neutral-600 bg-neutral-700 text-sm text-neutral-300 hover:border-sky-400 transition-colors duration-150'
                        }
                    >
                        <FontAwesomeIcon icon={faSearch} className={'mr-3 text-neutral-400'} />
                        Search servers
                    </button>
                    <div className={'flex-1 hidden sm:block'} />
                    {links.length > 0 && (
                        <div className={'relative'}>
                            <button
                                onClick={() => setSupportOpen((o) => !o)}
                                className={
                                    'flex items-center h-10 px-4 rounded-full border border-neutral-600 bg-neutral-700 text-sm text-neutral-100 hover:border-sky-400'
                                }
                            >
                                <FontAwesomeIcon icon={faLifeRing} className={'mr-2 text-sky-300'} />
                                Support
                                <FontAwesomeIcon
                                    icon={faChevronDown}
                                    className={`ml-2 text-2xs transition-transform duration-200 ${
                                        supportOpen ? 'rotate-180' : ''
                                    }`}
                                />
                            </button>
                            {supportOpen && (
                                <>
                                    <div className={'fixed inset-0 z-40'} onClick={() => setSupportOpen(false)} />
                                    <div
                                        className={
                                            'pc-fade absolute right-0 mt-2 w-56 z-50 rounded-xl border border-neutral-600 bg-neutral-700 p-1 shadow-2xl'
                                        }
                                    >
                                        {links.map((l) => (
                                            <a
                                                key={l.title}
                                                href={l.url}
                                                target={'_blank'}
                                                rel={'noreferrer noopener'}
                                                onClick={() => setSupportOpen(false)}
                                                className={
                                                    'flex items-center px-3 py-2 rounded-lg text-sm text-neutral-200 no-underline hover:bg-neutral-600 hover:text-sky-200'
                                                }
                                            >
                                                <FontAwesomeIcon
                                                    icon={linkIcon(l.title)}
                                                    fixedWidth
                                                    className={'mr-3 text-neutral-400'}
                                                />
                                                {l.title}
                                            </a>
                                        ))}
                                    </div>
                                </>
                            )}
                        </div>
                    )}
                    <button
                        onClick={logout}
                        title={'Sign out'}
                        className={
                            'flex-none w-10 h-10 rounded-full border border-neutral-600 bg-neutral-700 text-red-400 hover:border-red-400'
                        }
                    >
                        <FontAwesomeIcon icon={faSignOutAlt} />
                    </button>
                </div>
                {children}
            </div>
        </div>
    );
};
