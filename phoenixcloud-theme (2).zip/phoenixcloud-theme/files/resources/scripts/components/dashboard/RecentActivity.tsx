import React from 'react';
import { formatDistanceToNowStrict } from 'date-fns';
import { useActivityLogs } from '@/api/account/activity';
import { Link } from 'react-router-dom';

// "auth:success" -> ["Auth", "Success"],  "server:backup.start" -> ["Server", "Backup start"]
const humanize = (event: string): [string, string] => {
    const [group, ...rest] = event.split(':');
    const detail = rest.join(':').replace(/[._-]/g, ' ');
    const cap = (v: string) => (v ? v.charAt(0).toUpperCase() + v.slice(1) : v);

    return [cap(group), cap(detail) || cap(group)];
};

export default ({ className }: { className?: string }) => {
    const { data, error } = useActivityLogs({ page: 1 }, { revalidateOnMount: true });
    const items = (data?.items || []).slice(0, 6);

    return (
        <div className={`pc-card pc-fade-3 rounded-xl p-5 ${className || ''}`}>
            <div className={'flex items-baseline justify-between'}>
                <h3 className={'text-base font-semibold text-neutral-100'}>Recent activity</h3>
                <Link to={'/account/activity'} className={'text-xs text-sky-300 no-underline hover:text-sky-200'}>
                    View all
                </Link>
            </div>
            <ul className={'mt-4 space-y-4'}>
                {!data && !error && <li className={'text-sm text-neutral-400'}>Loading…</li>}
                {error && <li className={'text-sm text-neutral-400'}>Could not load activity.</li>}
                {data && items.length === 0 && <li className={'text-sm text-neutral-400'}>Nothing yet.</li>}
                {items.map((log) => {
                    const [group, detail] = humanize(log.event);

                    return (
                        <li key={log.id} className={'flex items-start'}>
                            <span className={'mt-1.5 mr-3 w-2 h-2 rounded-full bg-sky-400 flex-none'} />
                            <div className={'flex-1 min-w-0'}>
                                <p className={'text-sm font-medium text-neutral-100 truncate'}>{detail}</p>
                                <p className={'text-xs text-neutral-400'}>{group}</p>
                            </div>
                            <span className={'text-xs text-neutral-400 flex-none ml-2'}>
                                {formatDistanceToNowStrict(log.timestamp)} ago
                            </span>
                        </li>
                    );
                })}
            </ul>
        </div>
    );
};
