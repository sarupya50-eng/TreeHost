import React from 'react';
import { Link } from 'react-router-dom';
import { formatDistanceToNowStrict } from 'date-fns';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheckCircle, faCloudDownloadAlt } from '@fortawesome/free-solid-svg-icons';
import { ServerContext } from '@/state/server';
import Can from '@/components/elements/Can';
import useServerBackups from '@/api/swr/getServerBackups';
import { bytesToString } from '@/lib/formatters';

// Slim status strip under the header: when the last good backup finished and how many are kept.
export default ({ className }: { className?: string }) => {
    const id = ServerContext.useStoreState((state) => state.server.data!.id);
    const limit = ServerContext.useStoreState((state) => state.server.data!.featureLimits.backups);
    const { data } = useServerBackups();

    if (!limit) return null;

    const done = (data?.items || [])
        .filter((b) => b.isSuccessful && b.completedAt)
        .sort((a, b) => b.completedAt!.getTime() - a.completedAt!.getTime());
    const last = done[0];

    return (
        <Can action={'backup.read'}>
            <Link
                to={`/server/${id}/backups`}
                className={`flex flex-wrap items-center justify-between gap-2 rounded-xl border border-neutral-600 bg-neutral-700 px-4 py-2.5 text-sm no-underline hover:border-sky-400 ${
                    className || ''
                }`}
            >
                <span className={'flex items-center text-neutral-200'}>
                    <FontAwesomeIcon icon={faCloudDownloadAlt} className={'text-sky-300 mr-3'} />
                    {last ? (
                        <>
                            Last backup&nbsp;
                            <strong className={'text-neutral-50'}>
                                {formatDistanceToNowStrict(last.completedAt!)} ago
                            </strong>
                            <FontAwesomeIcon icon={faCheckCircle} className={'text-green-400 ml-2'} />
                            <span className={'text-neutral-400 ml-2'}>({bytesToString(last.bytes)})</span>
                        </>
                    ) : (
                        <span className={'text-neutral-300'}>
                            {data ? 'No backups yet. Create one in Backups.' : 'Checking backups…'}
                        </span>
                    )}
                </span>
                {data && (
                    <span className={'text-xs text-neutral-400'}>
                        {data.backupCount} / {limit} kept
                    </span>
                )}
            </Link>
        </Can>
    );
};
