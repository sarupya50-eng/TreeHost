import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IconDefinition } from '@fortawesome/free-solid-svg-icons';
import classNames from 'classnames';
import CopyOnClick from '@/components/elements/CopyOnClick';

interface StatBlockProps {
    title: string;
    copyOnClick?: string;
    color?: string | undefined;
    icon: IconDefinition;
    children: React.ReactNode;
    className?: string;
    // Recent values drawn as a faint sparkline along the bottom of the tile.
    spark?: number[];
}

const Spark = ({ data }: { data: number[] }) => {
    if (data.length < 2) return null;
    const max = Math.max(...data, 1);
    const w = 100;
    const h = 24;
    const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - (v / max) * (h - 3) - 1}`);

    return (
        <svg
            className={'absolute bottom-0 left-0 w-full h-7 pointer-events-none'}
            viewBox={`0 0 ${w} ${h}`}
            preserveAspectRatio={'none'}
        >
            <polygon points={`0,${h} ${pts.join(' ')} ${w},${h}`} fill={'rgba(125,211,252,0.10)'} />
            <polyline
                points={pts.join(' ')}
                fill={'none'}
                stroke={'#7dd3fc'}
                strokeWidth={1.4}
                vectorEffect={'non-scaling-stroke'}
                opacity={0.8}
            />
        </svg>
    );
};

// Compact stat tile. `color` (e.g. bg-red-500) draws a warning rail on the left edge.
export default ({ title, copyOnClick, icon, color, className, children, spark }: StatBlockProps) => (
    <CopyOnClick text={copyOnClick}>
        <div
            className={classNames(
                'relative overflow-hidden rounded-xl border border-gray-600 bg-gray-700 px-4 pt-3 transition-colors duration-150 hover:border-sky-400',
                spark ? 'pb-8' : 'pb-3',
                className
            )}
        >
            {color && color !== 'bg-gray-700' && (
                <div className={classNames('absolute left-0 top-3 bottom-3 w-1 rounded-r', color)} />
            )}
            <p className={'flex items-center text-xs uppercase tracking-wider text-gray-300'}>
                <FontAwesomeIcon icon={icon} className={'mr-2 text-sky-300'} />
                {title}
            </p>
            <div className={'relative z-10 mt-1 text-lg font-semibold text-gray-50 truncate'}>{children}</div>
            {spark && <Spark data={spark} />}
        </div>
    </CopyOnClick>
);
