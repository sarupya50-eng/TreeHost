import React from 'react';
import {
    faClock,
    faCloudDownloadAlt,
    faArrowDown,
    faArrowUp,
    faCopy,
    faHdd,
    faMemory,
    faMicrochip,
} from '@fortawesome/free-solid-svg-icons';
import { bytesToString, ip } from '@/lib/formatters';
import useServerStats from '@/components/server/useServerStats';
import { ServerContext } from '@/state/server';
import UptimeDuration from '@/components/server/UptimeDuration';
import StatBlock from '@/components/server/console/StatBlock';
import classNames from 'classnames';
import { capitalize } from '@/lib/strings';
import CopyOnClick from '@/components/elements/CopyOnClick';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const getBackgroundColor = (value: number, max: number | null): string | undefined => {
    const delta = !max ? 0 : value / max;

    if (delta > 0.8) {
        if (delta > 0.9) {
            return 'bg-red-500';
        }
        return 'bg-yellow-500';
    }

    return undefined;
};

const Limit = ({ limit, children }: { limit: string | null; children: React.ReactNode }) => (
    <>
        {children}
        <span className={'ml-1 text-gray-300 text-[70%] select-none'}>/ {limit || <>&infin;</>}</span>
    </>
);

const ServerDetailsBlock = ({ className }: { className?: string }) => {
    const { stats, hist, status, limits, textLimits } = useServerStats();

    const allocation = ServerContext.useStoreState((state) => {
        const match = state.server.data!.allocations.find((allocation) => allocation.isDefault);

        return !match ? 'n/a' : `${match.alias || ip(match.ip)}:${match.port}`;
    });

    return (
        <div className={classNames('grid grid-cols-2 lg:grid-cols-1 gap-2 md:gap-3 content-start', className)}>
            <CopyOnClick text={allocation}>
                <div
                    className={
                        'col-span-2 lg:col-span-1 rounded-xl p-4 cursor-pointer border border-sky-300 border-opacity-40'
                    }
                    style={{ background: 'linear-gradient(135deg, #7dd3fc 0%, #0284c7 100%)' }}
                >
                    <p className={'flex items-center text-xs font-semibold text-gray-900'}>
                        Copy address <FontAwesomeIcon icon={faCopy} className={'ml-2'} />
                    </p>
                    <p className={'mt-2 font-semibold text-gray-900 text-sm break-all'}>
                        <span className={'pc-reveal'} tabIndex={0}>
                            {allocation}
                        </span>
                    </p>
                    <p className={'mt-1 text-xs text-gray-800'}>Hover to reveal · click to copy.</p>
                </div>
            </CopyOnClick>
            <StatBlock
                icon={faClock}
                title={'Uptime'}
                color={getBackgroundColor(status === 'running' ? 0 : status !== 'offline' ? 9 : 10, 10)}
            >
                {status === null ? (
                    'Offline'
                ) : stats.uptime > 0 ? (
                    <UptimeDuration uptime={stats.uptime / 1000} />
                ) : (
                    capitalize(status)
                )}
            </StatBlock>
            <StatBlock
                icon={faMicrochip}
                title={'CPU'}
                spark={hist.cpu}
                color={getBackgroundColor(stats.cpu, limits.cpu)}
            >
                {status === 'offline' ? (
                    <span className={'text-gray-400'}>Offline</span>
                ) : (
                    <Limit limit={textLimits.cpu}>{stats.cpu.toFixed(2)}%</Limit>
                )}
            </StatBlock>
            <StatBlock
                icon={faMemory}
                title={'Memory'}
                spark={hist.mem}
                color={getBackgroundColor(stats.memory / 1024, limits.memory * 1024)}
            >
                {status === 'offline' ? (
                    <span className={'text-gray-400'}>Offline</span>
                ) : (
                    <Limit limit={textLimits.memory}>{bytesToString(stats.memory)}</Limit>
                )}
            </StatBlock>
            <StatBlock icon={faHdd} title={'Disk'} color={getBackgroundColor(stats.disk / 1024, limits.disk * 1024)}>
                <Limit limit={textLimits.disk}>{bytesToString(stats.disk)}</Limit>
            </StatBlock>
            <StatBlock icon={faCloudDownloadAlt} title={'Network'} spark={hist.net}>
                {status === 'offline' ? (
                    <span className={'text-gray-400'}>Offline</span>
                ) : (
                    <span className={'text-base'}>
                        <FontAwesomeIcon icon={faArrowDown} className={'text-sky-300 mr-1 text-xs'} />
                        {bytesToString(stats.rx)}
                        <FontAwesomeIcon icon={faArrowUp} className={'text-green-400 ml-3 mr-1 text-xs'} />
                        {bytesToString(stats.tx)}
                    </span>
                )}
            </StatBlock>
        </div>
    );
};

export default ServerDetailsBlock;
