import { useEffect, useMemo, useState } from 'react';
import { ServerContext } from '@/state/server';
import { SocketEvent, SocketRequest } from '@/components/server/events';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import { bytesToString, mbToBytes } from '@/lib/formatters';

export type LiveStats = Record<'memory' | 'cpu' | 'disk' | 'uptime' | 'rx' | 'tx', number>;

// Live websocket stats for the current server, plus short histories used for sparklines.
export default () => {
    const [stats, setStats] = useState<LiveStats>({ memory: 0, cpu: 0, disk: 0, uptime: 0, tx: 0, rx: 0 });
    const [hist, setHist] = useState<{ cpu: number[]; mem: number[]; net: number[] }>({ cpu: [], mem: [], net: [] });

    const status = ServerContext.useStoreState((state) => state.status.value);
    const connected = ServerContext.useStoreState((state) => state.socket.connected);
    const instance = ServerContext.useStoreState((state) => state.socket.instance);
    const limits = ServerContext.useStoreState((state) => state.server.data!.limits);

    const textLimits = useMemo(
        () => ({
            cpu: limits?.cpu ? `${limits.cpu}%` : null,
            memory: limits?.memory ? bytesToString(mbToBytes(limits.memory)) : null,
            disk: limits?.disk ? bytesToString(mbToBytes(limits.disk)) : null,
        }),
        [limits]
    );

    useEffect(() => {
        if (!connected || !instance) return;
        instance.send(SocketRequest.SEND_STATS);
    }, [instance, connected]);

    useWebsocketEvent(SocketEvent.STATS, (data) => {
        let s: any = {};
        try {
            s = JSON.parse(data);
        } catch (e) {
            return;
        }

        setHist((h) => ({
            cpu: [...h.cpu, s.cpu_absolute].slice(-40),
            mem: [...h.mem, s.memory_bytes].slice(-40),
            net: [...h.net, (s.network?.rx_bytes || 0) + (s.network?.tx_bytes || 0)].slice(-40),
        }));
        setStats({
            memory: s.memory_bytes,
            cpu: s.cpu_absolute,
            disk: s.disk_bytes,
            tx: s.network?.tx_bytes || 0,
            rx: s.network?.rx_bytes || 0,
            uptime: s.uptime || 0,
        });
    });

    return { stats, hist, status, limits, textLimits };
};
