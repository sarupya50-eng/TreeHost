import React from 'react';
import { faCloudDownloadAlt, faHdd, faMemory, faMicrochip } from '@fortawesome/free-solid-svg-icons';
import { ServerContext } from '@/state/server';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import Spinner from '@/components/elements/Spinner';
import CopyOnClick from '@/components/elements/CopyOnClick';
import StatBlock from '@/components/server/console/StatBlock';
import StatGraphs from '@/components/server/console/StatGraphs';
import ServerHeader from '@/components/server/ServerHeader';
import UptimeDuration from '@/components/server/UptimeDuration';
import NoticeBanner from '@/components/layout/NoticeBanner';
import BackupBar from '@/components/server/console/BackupBar';
import useServerStats from '@/components/server/useServerStats';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import { capitalize } from '@/lib/strings';

const Row = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div className={'flex items-center justify-between px-5 py-3 border-b border-gray-600 last:border-0'}>
        <span className={'text-sm text-gray-300'}>{label}</span>
        <span className={'text-sm font-medium text-gray-50 text-right break-all ml-4'}>{children}</span>
    </div>
);

const Limit = ({ limit, children }: { limit: string | null; children: React.ReactNode }) => (
    <>
        {children}
        <span className={'ml-1 text-gray-300 text-[70%] select-none'}>/ {limit || <>&infin;</>}</span>
    </>
);

// Ring showing disk used against the plan limit.
const DiskRing = ({ used, limitMb }: { used: number; limitMb: number }) => {
    const limit = limitMb > 0 ? mbToBytes(limitMb) : 0;
    const pct = limit > 0 ? Math.min(100, (used / limit) * 100) : 0;
    const r = 42;
    const c = 2 * Math.PI * r;

    return (
        <div className={'relative w-32 h-32 flex-none'}>
            <svg viewBox={'0 0 100 100'} className={'w-full h-full -rotate-90'}>
                <circle
                    cx={50}
                    cy={50}
                    r={r}
                    fill={'none'}
                    strokeWidth={9}
                    className={'stroke-current text-gray-600'}
                />
                <circle
                    cx={50}
                    cy={50}
                    r={r}
                    fill={'none'}
                    strokeWidth={9}
                    strokeLinecap={'round'}
                    className={'stroke-current text-sky-300'}
                    strokeDasharray={c}
                    strokeDashoffset={c - (c * pct) / 100}
                    style={{ transition: 'stroke-dashoffset 0.8s cubic-bezier(0.22, 1, 0.36, 1)' }}
                />
            </svg>
            <div className={'absolute inset-0 flex flex-col items-center justify-center'}>
                <span className={'text-2xl font-semibold text-gray-50'}>{limit > 0 ? `${Math.round(pct)}%` : '∞'}</span>
                <span className={'text-2xs uppercase tracking-wider text-gray-400'}>Used</span>
            </div>
        </div>
    );
};

export default () => {
    const { stats, hist, status, limits, textLimits } = useServerStats();
    const node = ServerContext.useStoreState((state) => state.server.data!.node);
    const id = ServerContext.useStoreState((state) => state.server.data!.id);
    const sftp = ServerContext.useStoreState((state) => state.server.data!.sftpDetails);
    const address = ServerContext.useStoreState((state) => {
        const a = state.server.data!.allocations.find((x) => x.isDefault);

        return a ? `${a.alias || ip(a.ip)}:${a.port}` : 'n/a';
    });
    const offline = status === 'offline';
    const free = limits.disk > 0 ? Math.max(0, mbToBytes(limits.disk) - stats.disk) : 0;

    return (
        <ServerContentBlock title={'Overview'}>
            <ServerHeader className={'mb-4'} />
            <NoticeBanner className={'mb-4 pc-fade-2'} />
            <BackupBar className={'mb-4 pc-fade-2'} />

            <div className={'grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4 pc-fade-3'}>
                <StatBlock icon={faMicrochip} title={'CPU'} spark={hist.cpu}>
                    {offline ? (
                        <span className={'text-gray-400'}>Offline</span>
                    ) : (
                        <Limit limit={textLimits.cpu}>{stats.cpu.toFixed(1)}%</Limit>
                    )}
                </StatBlock>
                <StatBlock icon={faMemory} title={'Memory'} spark={hist.mem}>
                    {offline ? (
                        <span className={'text-gray-400'}>Offline</span>
                    ) : (
                        <Limit limit={textLimits.memory}>{bytesToString(stats.memory)}</Limit>
                    )}
                </StatBlock>
                <StatBlock icon={faHdd} title={'Disk'}>
                    <Limit limit={textLimits.disk}>{bytesToString(stats.disk)}</Limit>
                </StatBlock>
                <StatBlock icon={faCloudDownloadAlt} title={'Network'} spark={hist.net}>
                    {offline ? (
                        <span className={'text-gray-400'}>Offline</span>
                    ) : (
                        <span className={'text-base'}>
                            ↓ {bytesToString(stats.rx)} &nbsp; ↑ {bytesToString(stats.tx)}
                        </span>
                    )}
                </StatBlock>
            </div>

            <div className={'grid grid-cols-1 md:grid-cols-3 gap-3 mb-4 pc-fade-3'}>
                <Spinner.Suspense>
                    <StatGraphs />
                </Spinner.Suspense>
            </div>

            <div className={'grid grid-cols-1 lg:grid-cols-3 gap-3 pc-fade-4'}>
                <div className={'pc-card rounded-2xl p-5'}>
                    <h3 className={'font-header font-semibold text-gray-50 mb-4'}>Disk usage</h3>
                    <div className={'flex items-center gap-6'}>
                        <DiskRing used={stats.disk} limitMb={limits.disk} />
                        <dl className={'flex-1 text-sm space-y-2'}>
                            <div className={'flex justify-between'}>
                                <dt className={'text-gray-300'}>Used</dt>
                                <dd className={'font-medium text-gray-50'}>{bytesToString(stats.disk)}</dd>
                            </div>
                            <div className={'flex justify-between'}>
                                <dt className={'text-gray-300'}>Free</dt>
                                <dd className={'font-medium text-gray-50'}>
                                    {limits.disk > 0 ? bytesToString(free) : '∞'}
                                </dd>
                            </div>
                            <div className={'flex justify-between'}>
                                <dt className={'text-gray-300'}>Limit</dt>
                                <dd className={'font-medium text-gray-50'}>{textLimits.disk || '∞'}</dd>
                            </div>
                        </dl>
                    </div>
                </div>

                <div className={'pc-card rounded-2xl lg:col-span-2'}>
                    <h3 className={'font-header font-semibold text-gray-50 px-5 pt-5 pb-3'}>Server info</h3>
                    <Row label={'Status'}>{capitalize(status || 'offline')}</Row>
                    <Row label={'Uptime'}>
                        {stats.uptime > 0 ? <UptimeDuration uptime={stats.uptime / 1000} /> : '—'}
                    </Row>
                    <Row label={'Address'}>
                        <CopyOnClick text={address}>
                            <span className={'pc-reveal'} tabIndex={0}>
                                {address}
                            </span>
                        </CopyOnClick>
                    </Row>
                    <Row label={'Node'}>{node}</Row>
                    <Row label={'SFTP'}>
                        <span className={'pc-reveal'} tabIndex={0}>
                            {sftp.ip}:{sftp.port}
                        </span>
                    </Row>
                    <Row label={'Server ID'}>
                        <span className={'font-mono'}>{id}</span>
                    </Row>
                </div>
            </div>
        </ServerContentBlock>
    );
};
