import React from 'react';
import { ServerContext } from '@/state/server';
import Can from '@/components/elements/Can';
import PowerButtons from '@/components/server/console/PowerButtons';

// Name, status badge and power controls. Shown at the top of the Overview and Console pages.
export default ({ className }: { className?: string }) => {
    const name = ServerContext.useStoreState((state) => state.server.data!.name);
    const description = ServerContext.useStoreState((state) => state.server.data!.description);
    const node = ServerContext.useStoreState((state) => state.server.data!.node);
    const status = ServerContext.useStoreState((state) => state.status.value);

    return (
        <div className={`pc-card pc-fade rounded-2xl p-5 ${className || ''}`}>
            <div className={'flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4'}>
                <div className={'min-w-0'}>
                    <div className={'flex items-center gap-3'}>
                        <h1 className={'font-header font-semibold text-2xl text-gray-50 truncate'}>{name}</h1>
                        <span
                            className={`flex-none text-2xs font-semibold uppercase tracking-wider rounded-full px-2 py-0.5 border ${
                                status === 'running'
                                    ? 'text-green-300 border-green-400 bg-green-500 bg-opacity-10'
                                    : status === 'offline' || !status
                                    ? 'text-red-300 border-red-400 bg-red-500 bg-opacity-10'
                                    : 'text-yellow-300 border-yellow-400 bg-yellow-500 bg-opacity-10'
                            }`}
                        >
                            {status || 'offline'}
                        </span>
                    </div>
                    <p className={'text-sm text-gray-300 mt-1 truncate'}>
                        {description || node}
                        {description && <span className={'text-gray-400'}> &middot; {node}</span>}
                    </p>
                </div>
                <Can action={['control.start', 'control.stop', 'control.restart']} matchAny>
                    <PowerButtons className={'flex sm:justify-end space-x-2'} />
                </Can>
            </div>
        </div>
    );
};
