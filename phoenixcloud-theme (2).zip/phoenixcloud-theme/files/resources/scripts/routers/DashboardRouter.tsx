import React from 'react';
import { Route, Switch } from 'react-router-dom';
import { faCogs, faEye, faKey, faLayerGroup, faTerminal, faUser } from '@fortawesome/free-solid-svg-icons';
import { useStoreState } from 'easy-peasy';
import Shell, { SideGroup, SideLink, linkIcon } from '@/components/layout/Shell';
import phoenix from '@/phoenix.config';
import DashboardContainer from '@/components/dashboard/DashboardContainer';
import { NotFound } from '@/components/elements/ScreenBlock';
import TransitionRouter from '@/TransitionRouter';
import { useLocation } from 'react-router';
import Spinner from '@/components/elements/Spinner';
import routes from '@/routers/routes';

const accountIcons = [faUser, faKey, faTerminal, faEye];

export default () => {
    const location = useLocation();
    const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);

    const nav = (
        <>
            <SideLink to={'/'} exact label={'Dashboard'} icon={faLayerGroup} />
            <SideGroup title={'Account'}>
                {routes.account
                    .filter((route) => !!route.name)
                    .map(({ path, name, exact = false }, i) => (
                        <SideLink
                            key={path}
                            to={`/account/${path}`.replace('//', '/')}
                            exact={exact}
                            label={name!}
                            icon={accountIcons[i] || faUser}
                        />
                    ))}
            </SideGroup>
            {phoenix.links.some((l) => l.url) && (
                <SideGroup title={'Links'}>
                    {phoenix.links
                        .filter((l) => l.url)
                        .map((l) => (
                            <SideLink key={l.title} to={l.url} label={l.title} icon={linkIcon(l.title)} external />
                        ))}
                </SideGroup>
            )}
            {rootAdmin && (
                <SideGroup title={'Staff'}>
                    <SideLink to={'/admin'} label={'Admin Panel'} icon={faCogs} external />
                </SideGroup>
            )}
        </>
    );

    return (
        <Shell nav={nav}>
            <TransitionRouter>
                <React.Suspense fallback={<Spinner centered />}>
                    <Switch location={location}>
                        <Route path={'/'} exact>
                            <DashboardContainer />
                        </Route>
                        {routes.account.map(({ path, component: Component }) => (
                            <Route key={path} path={`/account/${path}`.replace('//', '/')} exact>
                                <Component />
                            </Route>
                        ))}
                        <Route path={'*'}>
                            <NotFound />
                        </Route>
                    </Switch>
                </React.Suspense>
            </TransitionRouter>
        </Shell>
    );
};
