# PhoenixCloud theme for Pterodactyl 1.15.x
Black matte panel with a left sidebar, server Overview page, card/list dashboard, console toolbar, hover-to-reveal IPs.

    unzip phoenixcloud-theme.zip && cd phoenixcloud-theme
    sudo bash install.sh violet     # or: ice

Backs up to ~/phoenixcloud-backup-* and prints the undo command. Prebuilt: no Node or yarn needed.

Edit links and the notice banner in `files/resources/scripts/phoenix.config.ts` (needs a rebuild:
`yarn install && yarn build:production` in /var/www/pterodactyl).
