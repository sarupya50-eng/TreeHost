#!/usr/bin/env bash
# PhoenixCloud theme for Pterodactyl Panel 1.15.x  (prebuilt - no Node/yarn needed)
# Usage: sudo bash install.sh [violet|ice]
set -euo pipefail
PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

[[ $EUID -eq 0 ]] || { echo "Run as root: sudo bash install.sh"; exit 1; }
[[ -f "$PANEL_DIR/artisan" ]] || { echo "No Pterodactyl panel at $PANEL_DIR (set PANEL_DIR=...)"; exit 1; }

V="${1:-}"
if [[ -z "$V" ]]; then
  read -r -p "Accent color - 1) violet  2) ice-blue [1]: " a
  [[ "${a:-1}" == "2" ]] && V=ice || V=violet
fi
[[ -d "$HERE/variants/$V/assets" && -d "$HERE/files" ]] || { echo "Missing files/ or variants/$V/ next to install.sh. Re-unzip the theme and run again."; exit 1; }

VER="$(grep -oP "'version' => '\K[^']+" "$PANEL_DIR/config/app.php" || true)"
echo "Panel version: ${VER:-unknown} (theme built for 1.15.x), accent: $V"
[[ "$VER" == 1.15.* ]] || { read -r -p "Version differs. Continue anyway? [y/N] " a; [[ "${a,,}" == y* ]] || exit 1; }

BK="$HOME/phoenixcloud-backup-$(date -u +%Y%m%d-%H%M%S)"
mkdir -p "$BK"
echo "Backing up to $BK"
tar czf "$BK/panel-files.tar.gz" -C "$PANEL_DIR" public/assets public/themes public/favicons resources tailwind.config.js package.json

cd "$PANEL_DIR"
php artisan down || true
# never leave the panel in maintenance mode, even if a step below fails
trap 'php artisan up >/dev/null 2>&1 || true' EXIT
# copy first, delete stale files after, so a failed copy never leaves the panel without assets
cp -a "$HERE/files/." "$PANEL_DIR/"
[[ -d "$HERE/variants/$V/files" ]] && cp -a "$HERE/variants/$V/files/." "$PANEL_DIR/"
cp -a "$HERE/variants/$V/assets/." "$PANEL_DIR/public/assets/"

keep="$( (ls "$HERE/variants/$V/assets"; ls "$HERE/files/public/assets") | sort -u )"
for f in public/assets/*; do
  [[ -f "$f" ]] || continue
  grep -qxF "$(basename "$f")" <<<"$keep" || rm -f "$f"
done

WEB_USER="$(stat -c '%U' "$PANEL_DIR/storage")"; WEB_GROUP="$(stat -c '%G' "$PANEL_DIR/storage")"
chown -R "$WEB_USER:$WEB_GROUP" public resources tailwind.config.js package.json || echo "Warning: could not chown; run: chown -R <webuser>: public resources"
php artisan view:clear
php artisan config:clear
php artisan up
trap - EXIT
echo
echo "PhoenixCloud theme ($V) installed. Hard-refresh the browser (Ctrl+Shift+R)."
echo "To undo: tar xzf $BK/panel-files.tar.gz -C $PANEL_DIR && php artisan view:clear"
