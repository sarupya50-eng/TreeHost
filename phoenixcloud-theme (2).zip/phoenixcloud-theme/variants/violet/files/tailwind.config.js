const colors = require('tailwindcss/colors');

// PhoenixCloud palette: matte black surfaces + ice-blue accents.
const gray = {
    50: '#f5f5f6',
    100: '#e6e6e8',
    200: '#d0d0d4',
    300: '#a3a3ab',
    400: '#74747d',
    500: '#3d3d44',
    600: '#26262b',
    700: '#141416',
    800: '#0b0b0c',
    900: '#070708',
};

module.exports = {
    content: [
        './resources/scripts/**/*.{js,ts,tsx}',
    ],
    theme: {
        extend: {
            fontFamily: {
                header: ['"Space Grotesk"', '"IBM Plex Sans"', 'system-ui', 'sans-serif'],
                sans: ['"Space Grotesk"', '"IBM Plex Sans"', 'system-ui', 'sans-serif'],
            },
            colors: {
                black: '#030304',
                // "primary" and "neutral" are deprecated, prefer the use of "blue" and "gray"
                // in new code.
                primary: colors.violet,
                blue: colors.violet,
                gray: gray,
                neutral: gray,
                cyan: colors.violet,
                sky: colors.violet,
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            transitionDuration: {
                250: '250ms',
            },
            borderColor: theme => ({
                default: theme('colors.neutral.400', 'currentColor'),
            }),
        },
    },
    plugins: [
        require('@tailwindcss/line-clamp'),
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ]
};
