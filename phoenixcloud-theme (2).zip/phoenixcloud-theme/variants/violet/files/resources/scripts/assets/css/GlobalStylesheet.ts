import tw from 'twin.macro';
import { createGlobalStyle } from 'styled-components/macro';
// @ts-expect-error untyped font file
import font from '@fontsource-variable/ibm-plex-sans/files/ibm-plex-sans-latin-wght-normal.woff2';
// @ts-expect-error untyped font file
import grotesk from '@fontsource-variable/space-grotesk/files/space-grotesk-latin-wght-normal.woff2';

export default createGlobalStyle`
    @font-face {
        font-family: 'IBM Plex Sans';
        font-style: normal;
        font-display: swap;
        font-weight: 100 700;
        src: url(${font}) format('woff2-variations');
        unicode-range: U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;
    }

    @font-face {
        font-family: 'Space Grotesk';
        font-style: normal;
        font-display: swap;
        font-weight: 300 700;
        src: url(${grotesk}) format('woff2-variations');
    }

    body {
        ${tw`font-sans bg-neutral-800 text-neutral-200`};
        letter-spacing: 0.015em;
        min-height: 100vh;
        background-color: #0b0b0c;
        background-image:
            radial-gradient(800px 420px at 90% -8%, rgba(196, 181, 253, 0.07), transparent 62%),
            radial-gradient(600px 420px at -5% 108%, rgba(196, 181, 253, 0.04), transparent 62%);
        background-attachment: fixed;
        -webkit-font-smoothing: antialiased;
    }

    /* ---- PhoenixCloud motion ---- */
    @keyframes pcFadeUp {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    @keyframes pcSweep {
        0% { transform: translateX(-120%); }
        100% { transform: translateX(320%); }
    }
    @keyframes pcPulse {
        0%, 100% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.55); }
        50% { box-shadow: 0 0 0 6px rgba(74, 222, 128, 0); }
    }

    .pc-fade { animation: pcFadeUp 0.45s cubic-bezier(0.22, 1, 0.36, 1) both; }
    .pc-fade-2 { animation: pcFadeUp 0.45s 0.07s cubic-bezier(0.22, 1, 0.36, 1) both; }
    .pc-fade-3 { animation: pcFadeUp 0.45s 0.14s cubic-bezier(0.22, 1, 0.36, 1) both; }
    .pc-fade-4 { animation: pcFadeUp 0.45s 0.21s cubic-bezier(0.22, 1, 0.36, 1) both; }

    .pc-lift {
        transition: transform 0.25s cubic-bezier(0.22, 1, 0.36, 1), border-color 0.25s ease, box-shadow 0.25s ease;
    }
    .pc-lift:hover {
        transform: translateY(-3px);
        box-shadow: 0 14px 34px -12px rgba(0, 0, 0, 0.9), 0 0 0 1px rgba(196, 181, 253, 0.25);
    }

    /* matte card with a thin light sweep along the top edge */
    .pc-card {
        position: relative;
        overflow: hidden;
        background: linear-gradient(160deg, #18181b 0%, #0e0e10 100%);
        border: 1px solid #26262b;
        box-shadow: 0 10px 30px -14px rgba(0, 0, 0, 0.9), inset 0 1px 0 rgba(255, 255, 255, 0.04);
    }
    .pc-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        height: 1px;
        width: 40%;
        background: linear-gradient(90deg, transparent, rgba(196, 181, 253, 0.7), transparent);
        animation: pcSweep 5s ease-in-out infinite;
        pointer-events: none;
    }

    /* Login wallpaper: tinted to the brand ice-blue and faded into the matte black. Delete the
       'filter' line to show the image in its original purple. */
    .pc-login-bg {
        position: fixed;
        inset: 0;
        z-index: -1;
        background:
            linear-gradient(180deg, rgba(11, 11, 12, 0.55) 0%, rgba(11, 11, 12, 0.92) 100%),
            url('/assets/bg-login.jpg') center / cover no-repeat;
        animation: pcFadeUp 1.2s ease both;
    }

    /* Same wallpaper on every page, darker so content stays readable. */
    .pc-bg {
        position: fixed;
        inset: 0;
        z-index: -1;
        pointer-events: none;
        background:
            linear-gradient(180deg, rgba(11, 11, 12, 0.78) 0%, rgba(11, 11, 12, 0.94) 70%),
            url('/assets/bg-login.jpg') center / cover no-repeat;
    }

    /* IP / address text stays blurred until hovered, focused or tapped. */
    .pc-reveal {
        filter: blur(6px);
        transition: filter 0.3s ease;
        cursor: pointer;
        user-select: none;
    }
    .pc-reveal:hover, .pc-reveal:focus, .pc-reveal:active {
        filter: blur(0);
        user-select: text;
    }

    .pc-live { animation: pcPulse 2s ease-out infinite; }

    a, button, input, select, textarea {
        transition: color 0.2s ease, background-color 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease, opacity 0.2s ease, transform 0.2s ease;
    }
    button:active:not(:disabled) { transform: scale(0.97); }

    @media (prefers-reduced-motion: reduce) {
        *, *::before, *::after { animation: none !important; transition: none !important; }
    }

    .pc-side-active {
        color: #f5f5f6 !important;
        background: linear-gradient(90deg, rgba(196, 181, 253, 0.14), rgba(196, 181, 253, 0.02)) !important;
        border-color: rgba(196, 181, 253, 0.3) !important;
    }

    .pc-side-active svg {
        color: #c4b5fd !important;
    }

    ::selection {
        background: rgba(196, 181, 253, 0.35);
    }

    h1, h2, h3, h4, h5, h6 {
        ${tw`font-medium tracking-normal font-header`};
    }

    p {
        ${tw`text-neutral-200 leading-snug font-sans`};
    }

    form {
        ${tw`m-0`};
    }

    textarea, select, input, button, button:focus, button:focus-visible {
        ${tw`outline-none`};
    }

    input[type=number]::-webkit-outer-spin-button,
    input[type=number]::-webkit-inner-spin-button {
        -webkit-appearance: none !important;
        margin: 0;
    }

    input[type=number] {
        -moz-appearance: textfield !important;
    }

    /* Scroll Bar Style */
    ::-webkit-scrollbar {
        background: none;
        width: 16px;
        height: 16px;
    }

    ::-webkit-scrollbar-thumb {
        border: solid 0 rgb(0 0 0 / 0%);
        border-right-width: 4px;
        border-left-width: 4px;
        -webkit-border-radius: 9px 4px;
        -webkit-box-shadow: inset 0 0 0 1px #3d3d44, inset 0 0 0 4px #26262b;
    }

    ::-webkit-scrollbar-track-piece {
        margin: 4px 0;
    }

    ::-webkit-scrollbar-thumb:horizontal {
        border-right-width: 0;
        border-left-width: 0;
        border-top-width: 4px;
        border-bottom-width: 4px;
        -webkit-border-radius: 4px 9px;
    }

    ::-webkit-scrollbar-corner {
        background: transparent;
    }
`;
