import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ITerminalOptions, Terminal } from 'xterm';
import { FitAddon } from 'xterm-addon-fit';
import { SearchAddon } from 'xterm-addon-search';
import { SearchBarAddon } from 'xterm-addon-search-bar';
import { WebLinksAddon } from 'xterm-addon-web-links';
import { Unicode11Addon } from 'xterm-addon-unicode11';
import { ScrollDownHelperAddon } from '@/plugins/XtermScrollDownHelperAddon';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import { ServerContext } from '@/state/server';
import { usePermissions } from '@/plugins/usePermissions';
import { theme as th } from 'twin.macro';
import useEventListener from '@/plugins/useEventListener';
import { debounce } from 'debounce';
import { usePersistedState } from '@/plugins/usePersistedState';
import { SocketEvent, SocketRequest } from '@/components/server/events';
import classNames from 'classnames';
import { ChevronRightIcon } from '@heroicons/react/solid';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCopy, faEraser, faMinus, faPlus, faSearch } from '@fortawesome/free-solid-svg-icons';

import 'xterm/css/xterm.css';
import styles from './style.module.css';

const theme = {
    background: '#050506',
    cursor: 'transparent',
    black: th`colors.black`.toString(),
    red: '#E54B4B',
    green: '#9ECE58',
    yellow: '#FAED70',
    blue: '#a78bfa',
    magenta: '#BB80B3',
    cyan: '#c4b5fd',
    white: '#d0d0d0',
    brightBlack: 'rgba(255, 255, 255, 0.2)',
    brightRed: '#FF5370',
    brightGreen: '#C3E88D',
    brightYellow: '#FFCB6B',
    brightBlue: '#ddd6fe',
    brightMagenta: '#C792EA',
    brightCyan: '#89DDFF',
    brightWhite: '#ffffff',
    selection: '#c4b5fd',
};

const terminalProps: ITerminalOptions = {
    disableStdin: true,
    cursorStyle: 'underline',
    allowTransparency: true,
    fontSize: 12,
    lineHeight: 1.25,
    fontFamily: th('fontFamily.mono'),
    rows: 30,
    theme: theme,
};

export default () => {
    const TERMINAL_PRELUDE = '\u001b[1m\u001b[36mphoenixcloud \u001b[90m›\u001b[0m ';
    const ref = useRef<HTMLDivElement>(null);
    const terminal = useMemo(() => new Terminal({ ...terminalProps }), []);
    const fitAddon = useMemo(() => new FitAddon(), []);
    const searchAddon = useMemo(() => new SearchAddon(), []);
    const searchBar = useMemo(() => new SearchBarAddon({ searchAddon }), []);
    const webLinksAddon = useMemo(() => new WebLinksAddon(), []);
    const unicode11Addon = useMemo(() => new Unicode11Addon(), []);
    const scrollDownHelperAddon = useMemo(() => new ScrollDownHelperAddon(), []);

    type Kind = 'info' | 'warn' | 'error';
    type Filter = 'all' | 'warn' | 'error';
    // Every line is kept here so the filter tabs can re-render the console without a reconnect.
    const lines = useRef<{ text: string; plain: string; kind: Kind }[]>([]);
    const filterRef = useRef<Filter>('all');
    const [filter, setFilterState] = useState<Filter>('all');
    const [counts, setCounts] = useState({ all: 0, warn: 0, error: 0 });
    const [fontSize, setFontSize] = usePersistedState<number>('pc:console:fontSize', 12);
    const [copied, setCopied] = useState(false);

    const classify = (plain: string): Kind =>
        /\b(error|exception|fatal|failed|traceback|unhandled|ERR!)\b/i.test(plain)
            ? 'error'
            : /\b(warn|warning|deprecat)/i.test(plain)
            ? 'warn'
            : 'info';

    const refreshCounts = useMemo(
        () =>
            debounce(() => {
                setCounts({
                    all: lines.current.length,
                    warn: lines.current.filter((l) => l.kind === 'warn').length,
                    error: lines.current.filter((l) => l.kind === 'error').length,
                });
            }, 250),
        []
    );

    const pushLine = (text: string, forceKind?: Kind) => {
        // eslint-disable-next-line no-control-regex
        const plain = text.replace(/\u001b\[[0-9;]*m/g, '');
        const prev = lines.current[lines.current.length - 1];
        // Stack-trace continuation lines stay with the error above them.
        const kind = forceKind || (prev && prev.kind === 'error' && /^\s+at\s/.test(plain) ? 'error' : classify(plain));
        lines.current.push({ text, plain, kind });
        if (lines.current.length > 2000) lines.current.shift();
        if (filterRef.current === 'all' || filterRef.current === kind) terminal.writeln(text);
        refreshCounts();
    };

    const setFilter = (next: Filter) => {
        filterRef.current = next;
        setFilterState(next);
        terminal.reset();
        lines.current.filter((l) => next === 'all' || l.kind === next).forEach((l) => terminal.writeln(l.text));
    };

    const copyLog = () => {
        const text = lines.current.map((l) => l.plain).join('\n');
        navigator.clipboard
            ?.writeText(text)
            .then(() => {
                setCopied(true);
                setTimeout(() => setCopied(false), 1500);
            })
            .catch(() => undefined);
    };

    const clearLog = () => {
        lines.current = [];
        terminal.clear();
        setCounts({ all: 0, warn: 0, error: 0 });
    };

    const changeFont = (delta: number) => {
        const next = Math.min(20, Math.max(9, (fontSize || 12) + delta));
        setFontSize(next);
        terminal.options.fontSize = next;
        fitAddon.fit();
    };
    const { connected, instance } = ServerContext.useStoreState((state) => state.socket);
    const [canSendCommands] = usePermissions(['control.console']);
    const serverId = ServerContext.useStoreState((state) => state.server.data!.id);
    const isTransferring = ServerContext.useStoreState((state) => state.server.data!.isTransferring);
    const [history, setHistory] = usePersistedState<string[]>(`${serverId}:command_history`, []);
    const [historyIndex, setHistoryIndex] = useState(-1);
    // SearchBarAddon has hardcoded z-index: 999 :(
    const zIndex = `
    .xterm-search-bar__addon {
        z-index: 10;
    }`;

    const handleConsoleOutput = (line: string, prelude = false) =>
        pushLine((prelude ? TERMINAL_PRELUDE : '') + line.replace(/(?:\r\n|\r|\n)$/im, '') + '\u001b[0m');

    const handleTransferStatus = (status: string) => {
        switch (status) {
            // Sent by either the source or target node if a failure occurs.
            case 'failure':
                pushLine(TERMINAL_PRELUDE + 'Transfer has failed.\u001b[0m', 'error');
                return;
        }
    };

    const handleDaemonErrorOutput = (line: string) =>
        pushLine(
            TERMINAL_PRELUDE + '\u001b[1m\u001b[41m' + line.replace(/(?:\r\n|\r|\n)$/im, '') + '\u001b[0m',
            'error'
        );

    const handlePowerChangeEvent = (state: string) =>
        pushLine(TERMINAL_PRELUDE + 'Server marked as ' + state + '...\u001b[0m', 'info');

    const handleCommandKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'ArrowUp') {
            const newIndex = Math.min(historyIndex + 1, history!.length - 1);

            setHistoryIndex(newIndex);
            e.currentTarget.value = history![newIndex] || '';

            // By default up arrow will also bring the cursor to the start of the line,
            // so we'll preventDefault to keep it at the end.
            e.preventDefault();
        }

        if (e.key === 'ArrowDown') {
            const newIndex = Math.max(historyIndex - 1, -1);

            setHistoryIndex(newIndex);
            e.currentTarget.value = history![newIndex] || '';
        }

        const command = e.currentTarget.value;
        if (e.key === 'Enter' && command.length > 0) {
            setHistory((prevHistory) => [command, ...prevHistory!].slice(0, 32));
            setHistoryIndex(-1);

            instance && instance.send('send command', command);
            e.currentTarget.value = '';
        }
    };

    useEffect(() => {
        if (connected && ref.current && !terminal.element) {
            terminal.loadAddon(fitAddon);
            terminal.loadAddon(searchAddon);
            terminal.loadAddon(searchBar);
            terminal.loadAddon(webLinksAddon);
            terminal.loadAddon(unicode11Addon);
            terminal.loadAddon(scrollDownHelperAddon);

            terminal.options.fontSize = fontSize || 12;
            terminal.open(ref.current);

            // Activate Unicode 11 for proper emoji and special character width handling
            terminal.unicode.activeVersion = '11';

            fitAddon.fit();
            searchBar.addNewStyle(zIndex);

            // Add support for capturing keys
            terminal.attachCustomKeyEventHandler((e: KeyboardEvent) => {
                if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
                    document.execCommand('copy');
                    return false;
                } else if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                    e.preventDefault();
                    searchBar.show();
                    return false;
                } else if (e.key === 'Escape') {
                    searchBar.hidden();
                }
                return true;
            });
        }
    }, [terminal, connected]);

    useEventListener(
        'resize',
        debounce(() => {
            if (terminal.element) {
                fitAddon.fit();
            }
        }, 100)
    );

    useEffect(() => {
        const listeners: Record<string, (s: string) => void> = {
            [SocketEvent.STATUS]: handlePowerChangeEvent,
            [SocketEvent.CONSOLE_OUTPUT]: handleConsoleOutput,
            [SocketEvent.INSTALL_OUTPUT]: handleConsoleOutput,
            [SocketEvent.TRANSFER_LOGS]: handleConsoleOutput,
            [SocketEvent.TRANSFER_STATUS]: handleTransferStatus,
            [SocketEvent.DAEMON_MESSAGE]: (line) => handleConsoleOutput(line, true),
            [SocketEvent.DAEMON_ERROR]: handleDaemonErrorOutput,
        };

        if (connected && instance) {
            // Do not clear the console if the server is being transferred.
            if (!isTransferring) {
                terminal.clear();
                lines.current = [];
            }

            Object.keys(listeners).forEach((key: string) => {
                instance.addListener(key, listeners[key]);
            });
            instance.send(SocketRequest.SEND_LOGS);
        }

        return () => {
            if (instance) {
                Object.keys(listeners).forEach((key: string) => {
                    instance.removeListener(key, listeners[key]);
                });
            }
        };
    }, [connected, instance]);

    return (
        <div className={classNames(styles.terminal, 'relative pc-fade-3')}>
            <SpinnerOverlay visible={!connected} size={'large'} />
            <div className={styles.toolbar}>
                <span className={'flex items-center mr-2 text-sm font-semibold text-gray-100'}>
                    <span
                        className={classNames(
                            'inline-block w-2 h-2 rounded-full mr-2',
                            connected ? 'bg-green-400 pc-live' : 'bg-gray-400'
                        )}
                    />
                    Console
                </span>
                {(
                    [
                        ['all', 'All', counts.all],
                        ['warn', 'Warnings', counts.warn],
                        ['error', 'Errors', counts.error],
                    ] as [Filter, string, number][]
                ).map(([key, label, count]) => (
                    <button
                        key={key}
                        type={'button'}
                        className={classNames(styles.tab, { [styles.active]: filter === key })}
                        onClick={() => setFilter(key)}
                    >
                        {label}
                        <span className={'ml-2 text-2xs text-gray-400'}>{count}</span>
                    </button>
                ))}
                <div className={'flex-1'} />
                <button
                    type={'button'}
                    className={styles.tool}
                    title={'Search (Ctrl+F)'}
                    onClick={() => searchBar.show()}
                >
                    <FontAwesomeIcon icon={faSearch} />
                </button>
                <button type={'button'} className={styles.tool} title={'Smaller text'} onClick={() => changeFont(-1)}>
                    <FontAwesomeIcon icon={faMinus} />
                </button>
                <span className={'text-2xs text-gray-400 w-5 text-center select-none'}>{fontSize}</span>
                <button type={'button'} className={styles.tool} title={'Larger text'} onClick={() => changeFont(1)}>
                    <FontAwesomeIcon icon={faPlus} />
                </button>
                <button type={'button'} className={styles.tool} title={'Copy log'} onClick={copyLog}>
                    {copied ? <span className={'text-green-400'}>Copied</span> : <FontAwesomeIcon icon={faCopy} />}
                </button>
                <button type={'button'} className={styles.tool} title={'Clear'} onClick={clearLog}>
                    <FontAwesomeIcon icon={faEraser} />
                </button>
            </div>
            <div className={styles.container}>
                <div className={'h-full'}>
                    <div id={styles.terminal} ref={ref} />
                </div>
            </div>
            {canSendCommands && (
                <div className={styles.command_bar}>
                    <input
                        className={classNames('peer', styles.command_input)}
                        type={'text'}
                        placeholder={'Type a command and press Enter...'}
                        aria-label={'Console command input.'}
                        disabled={!instance || !connected}
                        onKeyDown={handleCommandKeyDown}
                        autoCorrect={'off'}
                        autoCapitalize={'none'}
                    />
                    <div className={styles.command_icon}>
                        <ChevronRightIcon className={'w-5 h-5'} />
                    </div>
                </div>
            )}
        </div>
    );
};
