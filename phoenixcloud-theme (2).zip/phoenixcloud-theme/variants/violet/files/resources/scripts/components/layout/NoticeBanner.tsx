import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBullhorn, faTimes } from '@fortawesome/free-solid-svg-icons';
import { usePersistedState } from '@/plugins/usePersistedState';
import phoenix from '@/phoenix.config';

export default ({ className }: { className?: string }) => {
    const { title, text } = phoenix.notice;
    const key = `pc:notice:${text}`;
    const [dismissed, setDismissed] = usePersistedState<boolean>(key, false);

    if (!text || dismissed) return null;

    const warn = phoenix.notice.tone === 'warn';

    return (
        <div
            className={`relative flex items-start rounded-xl border p-4 pr-10 ${
                warn ? 'border-yellow-400 border-opacity-40' : 'border-sky-400 border-opacity-40'
            } ${className || ''}`}
            style={{
                background: warn
                    ? 'linear-gradient(90deg, rgba(250,204,21,0.16), rgba(250,204,21,0.03))'
                    : 'linear-gradient(90deg, rgba(167, 139, 250,0.16), rgba(167, 139, 250,0.04))',
            }}
        >
            <FontAwesomeIcon icon={faBullhorn} className={`mt-1 mr-3 ${warn ? 'text-yellow-300' : 'text-sky-300'}`} />
            <div>
                <p className={`font-semibold text-sm ${warn ? 'text-yellow-100' : 'text-sky-100'}`}>{title}</p>
                <p className={'text-sm text-neutral-200'}>{text}</p>
            </div>
            <button
                onClick={() => setDismissed(true)}
                className={'absolute top-3 right-3 text-neutral-300 hover:text-white'}
                title={'Dismiss'}
            >
                <FontAwesomeIcon icon={faTimes} />
            </button>
        </div>
    );
};
