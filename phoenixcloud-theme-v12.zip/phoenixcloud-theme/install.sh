#!/usr/bin/env bash
# PhoenixCloud theme for Pterodactyl Panel 1.15.x  (prebuilt - no Node/yarn needed)
# Usage: sudo bash install.sh [violet|ice]
set -euo pipefail
PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

[[ $EUID -eq 0 ]] || { echo "Run as root: sudo bash install.sh"; exit 1; }
[[ -f "$PANEL_DIR/artisan" ]] || { echo "No Pterodactyl panel at $PANEL_DIR (set PANEL_DIR=...)"; exit 1; }

V="${1:-}"
if [[ -z "$V" ]]; then
  read -r -p "Accent color - 1) violet  2) ice-blue [1]: " a
  [[ "${a:-1}" == "2" ]] && V=ice || V=violet
fi
[[ -d "$HERE/variants/$V/assets" && -d "$HERE/files" ]] || { echo "Missing files/ or variants/$V/ next to install.sh. Re-unzip the theme and run again."; exit 1; }

VER="$(grep -oP "'version' => '\K[^']+" "$PANEL_DIR/config/app.php" || true)"
echo "Panel version: ${VER:-unknown} (theme built for 1.15.x), accent: $V"
[[ "$VER" == 1.15.* ]] || { read -r -p "Version differs. Continue anyway? [y/N] " a; [[ "${a,,}" == y* ]] || exit 1; }

BK="$HOME/phoenixcloud-backup-$(date -u +%Y%m%d-%H%M%S)"
mkdir -p "$BK"
echo "Backing up to $BK"
tar czf "$BK/panel-files.tar.gz" -C "$PANEL_DIR" public/assets public/themes public/favicons resources routes tailwind.config.js webpack.config.js package.json

cd "$PANEL_DIR"
php artisan down || true
# never leave the panel in maintenance mode, even if a step below fails
trap 'php artisan up >/dev/null 2>&1 || true' EXIT
# copy first, delete stale files after, so a failed copy never leaves the panel without assets
cp -a "$HERE/files/." "$PANEL_DIR/"
[[ -d "$HERE/variants/$V/files" ]] && cp -a "$HERE/variants/$V/files/." "$PANEL_DIR/"
cp -a "$HERE/variants/$V/assets/." "$PANEL_DIR/public/assets/"

# Register page: add the route file to routes/auth.php (once)
grep -q "phoenix-auth.php" routes/auth.php || printf "\nrequire __DIR__ . '/phoenix-auth.php';\n" >> routes/auth.php
# AI assistant: register the route (once) and ask for an Anthropic API key (optional, Enter to skip)
grep -q "phoenix-ai.php" routes/api-client.php || printf "\nrequire __DIR__ . '/phoenix-ai.php';\n" >> routes/api-client.php
if ! grep -q '^PHOENIX_AI_KEY=.\+' .env 2>/dev/null; then
  AIK="${PHOENIX_AI_KEY:-}"
  if [[ -z "$AIK" ]]; then read -r -s -p "Anthropic API key for the AI assistant (Enter to skip): " AIK || true; echo; fi
  if [[ -n "$AIK" ]]; then
    sed -i '/^PHOENIX_AI_KEY=/d' .env
    printf 'PHOENIX_AI_KEY=%s\n' "$AIK" >> .env
    echo "AI key saved to .env"
  else
    echo "No key entered: the assistant will say it is not set up. Add PHOENIX_AI_KEY=... to $PANEL_DIR/.env later."
  fi
fi

keep="$( (ls "$HERE/variants/$V/assets"; ls "$HERE/files/public/assets") | sort -u )"
for f in public/assets/*; do
  [[ -f "$f" ]] || continue
  grep -qxF "$(basename "$f")" <<<"$keep" || rm -f "$f"
done

WEB_USER="$(stat -c '%U' "$PANEL_DIR/storage")"; WEB_GROUP="$(stat -c '%G' "$PANEL_DIR/storage")"
chown -R "$WEB_USER:$WEB_GROUP" public resources routes tailwind.config.js webpack.config.js package.json app/Http/Controllers/Api/Client/AssistantController.php app/Http/Controllers/Auth/RegisterController.php config/phoenix.php || echo "Warning: could not chown; run: chown -R <webuser>: public resources"
php artisan view:clear
php artisan config:clear
php artisan route:clear || true
php artisan up
trap - EXIT
echo
echo "PhoenixCloud theme ($V) installed. Hard-refresh the browser (Ctrl+Shift+R)."
echo "To undo: tar xzf $BK/panel-files.tar.gz -C $PANEL_DIR && php artisan view:clear"
