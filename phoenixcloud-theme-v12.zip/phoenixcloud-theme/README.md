# PhoenixCloud theme for Pterodactyl 1.15.x
Black matte panel with a left sidebar, server Overview page, card/list dashboard, console toolbar, hover-to-reveal IPs.

    unzip phoenixcloud-theme.zip && cd phoenixcloud-theme
    sudo bash install.sh violet     # or: ice

Backs up to ~/phoenixcloud-backup-* and prints the undo command. Prebuilt: no Node or yarn needed.

Edit links and the notice banner in `files/resources/scripts/phoenix.config.ts` (needs a rebuild:
`yarn install && yarn build:production` in /var/www/pterodactyl).

## v12
- New glass sign-in page with a live background (drifting colour glows + rising embers, slow zoom on the wallpaper). Respects reduced-motion.
- Register page at /auth/register (auto signs in after). Backend: `RegisterController.php`, route file `routes/phoenix-auth.php`. Close it with `PHOENIX_REGISTRATION=false` in .env (and `registration: false` in phoenix.config.ts to hide the link). Limited to 10 sign-ups per hour per IP; works with recaptcha if enabled.

## v11
- Thin outline icons everywhere (one shared shim, `OutlineIcons.tsx`, wired in `webpack.config.js`).
- AI assistant: chat bubble bottom-right on every page after login. Backend is `AssistantController.php` (key stays on the server). Set `PHOENIX_AI_KEY` in `.env` (the installer asks for it); optional `PHOENIX_AI_MODEL` (default claude-haiku-5-5) and `PHOENIX_AI_PROMPT`.

## v10
- Files page redesigned: search box, icon toolbar (Refresh / New folder / Upload / New file), breadcrumb bar, colored file-type icons, cleaner list.
- Wallpapers included: purple on the login page, black curve on every page after login (`public/themes/pterodactyl/{css,img}`).
