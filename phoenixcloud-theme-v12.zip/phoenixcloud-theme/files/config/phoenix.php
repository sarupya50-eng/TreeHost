<?php

return [
    // Public sign-up page. Set PHOENIX_REGISTRATION=false in .env to close it.
    'registration' => env('PHOENIX_REGISTRATION', true),

    'ai' => [
        // Set PHOENIX_AI_KEY in .env (Anthropic API key). Empty = assistant shows "not set up".
        'key' => env('PHOENIX_AI_KEY'),
        'model' => env('PHOENIX_AI_MODEL', 'claude-haiku-5-5'),
        // Optional extra instructions appended to the assistant's prompt (plans, ports, rules...).
        'prompt' => env('PHOENIX_AI_PROMPT', ''),
    ],
];
