<?php

namespace Pterodactyl\Http\Controllers\Auth;

use Ramsey\Uuid\Uuid;
use Illuminate\Http\Request;
use Pterodactyl\Rules\Username;
use Pterodactyl\Facades\Activity;
use Illuminate\Http\JsonResponse;
use Illuminate\Contracts\Hashing\Hasher;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Contracts\Repository\UserRepositoryInterface;

/**
 * Public sign-up for the PhoenixCloud panel. Creates a normal (non-admin) user.
 * Disable with PHOENIX_REGISTRATION=false in .env.
 */
class RegisterController extends Controller
{
    public function __construct(private UserRepositoryInterface $repository, private Hasher $hasher)
    {
    }

    public function __invoke(Request $request): JsonResponse
    {
        if (!filter_var(config('phoenix.registration', true), FILTER_VALIDATE_BOOLEAN)) {
            return new JsonResponse(['errors' => [[
                'code' => 'RegistrationClosed',
                'status' => '403',
                'detail' => 'Registration is currently closed.',
            ]]], 403);
        }

        $request->merge([
            'username' => mb_strtolower(trim((string) $request->input('username'))),
            'email' => mb_strtolower(trim((string) $request->input('email'))),
        ]);

        $data = $request->validate([
            'username' => ['required', 'string', 'between:3,32', 'unique:users,username', new Username()],
            'email' => 'required|email:strict|max:191|unique:users,email',
            'name_first' => 'required|string|between:1,50',
            'name_last' => 'required|string|between:1,50',
            'password' => 'required|string|min:8|max:128|confirmed',
        ]);

        // No account e-mail is sent here, so sign-up works even when the panel mailer is not configured.
        $user = $this->repository->create([
            'uuid' => Uuid::uuid4()->toString(),
            'username' => $data['username'],
            'email' => $data['email'],
            'name_first' => $data['name_first'],
            'name_last' => $data['name_last'],
            'password' => $this->hasher->make($data['password']),
            'root_admin' => false,
        ], true, true);

        Activity::event('user:user.create')
            ->subject($user)
            ->property(['email' => $user->email, 'username' => $user->username, 'admin' => false, 'self_registered' => true])
            ->log();

        return new JsonResponse(['data' => ['complete' => true]], 201);
    }
}
