import React, { useEffect, useState } from 'react';
import { httpErrorToHuman } from '@/api/http';
import { CSSTransition } from 'react-transition-group';
import Spinner from '@/components/elements/Spinner';
import FileObjectRow from '@/components/server/files/FileObjectRow';
import FileManagerBreadcrumbs from '@/components/server/files/FileManagerBreadcrumbs';
import { FileObject } from '@/api/server/files/loadDirectory';
import NewDirectoryButton from '@/components/server/files/NewDirectoryButton';
import { NavLink, useLocation } from 'react-router-dom';
import Can from '@/components/elements/Can';
import { ServerError } from '@/components/elements/ScreenBlock';
import tw from 'twin.macro';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFileMedical, faFolderOpen, faSearch, faSyncAlt } from '@fortawesome/free-solid-svg-icons';
import { ServerContext } from '@/state/server';
import useFileManagerSwr from '@/plugins/useFileManagerSwr';
import FileManagerStatus from '@/components/server/files/FileManagerStatus';
import MassActionsBar from '@/components/server/files/MassActionsBar';
import UploadButton from '@/components/server/files/UploadButton';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import { useStoreActions } from '@/state/hooks';
import ErrorBoundary from '@/components/elements/ErrorBoundary';
import { FileActionCheckbox } from '@/components/server/files/SelectFileCheckbox';
import { hashToPath } from '@/helpers';
import style from './style.module.css';

const sortFiles = (files: FileObject[]): FileObject[] => {
    const sortedFiles: FileObject[] = files
        .sort((a, b) => a.name.localeCompare(b.name))
        .sort((a, b) => (a.isFile === b.isFile ? 0 : a.isFile ? 1 : -1));
    return sortedFiles.filter((file, index) => index === 0 || file.name !== sortedFiles[index - 1].name);
};

export default () => {
    const id = ServerContext.useStoreState((state) => state.server.data!.id);
    const { hash } = useLocation();
    const { data: files, error, mutate, isValidating } = useFileManagerSwr();
    const [query, setQuery] = useState('');
    const directory = ServerContext.useStoreState((state) => state.files.directory);
    const clearFlashes = useStoreActions((actions) => actions.flashes.clearFlashes);
    const setDirectory = ServerContext.useStoreActions((actions) => actions.files.setDirectory);

    const setSelectedFiles = ServerContext.useStoreActions((actions) => actions.files.setSelectedFiles);
    const selectedFilesLength = ServerContext.useStoreState((state) => state.files.selectedFiles.length);

    useEffect(() => {
        clearFlashes('files');
        setSelectedFiles([]);
        setDirectory(hashToPath(hash));
        setQuery('');
    }, [hash]);

    useEffect(() => {
        mutate();
    }, [directory]);

    const onSelectAllClick = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSelectedFiles(e.currentTarget.checked ? visible.map((file) => file.name) : []);
    };

    const q = query.trim().toLowerCase();
    const visible = (files || []).filter((file) => !q || file.name.toLowerCase().includes(q));

    if (error) {
        return <ServerError message={httpErrorToHuman(error)} onRetry={() => mutate()} />;
    }

    return (
        <ServerContentBlock title={'File Manager'} showFlashKey={'files'}>
            <ErrorBoundary>
                <div className={style.toolbar + ' pc-fade'}>
                    <div className={style.search}>
                        <FontAwesomeIcon icon={faSearch} />
                        <input
                            type={'text'}
                            value={query}
                            onChange={(e) => setQuery(e.currentTarget.value)}
                            placeholder={'Search this folder'}
                            aria-label={'Search this folder'}
                        />
                    </div>
                    <div className={style.manager_actions}>
                        <FileManagerStatus />
                        <button type={'button'} className={style.tbtn} onClick={() => mutate()}>
                            <FontAwesomeIcon icon={faSyncAlt} spin={isValidating} /> Refresh
                        </button>
                        <Can action={'file.create'}>
                            <NewDirectoryButton className={style.tbtn} />
                            <UploadButton className={style.tbtn} />
                            <NavLink
                                to={`/server/${id}/files/new${window.location.hash}`}
                                className={`${style.tbtn} ${style.tbtn_primary}`}
                            >
                                <FontAwesomeIcon icon={faFileMedical} /> New file
                            </NavLink>
                        </Can>
                    </div>
                </div>
                <FileManagerBreadcrumbs
                    renderLeft={
                        <FileActionCheckbox
                            type={'checkbox'}
                            css={tw`mx-4`}
                            checked={visible.length > 0 && selectedFilesLength === visible.length}
                            onChange={onSelectAllClick}
                        />
                    }
                />
            </ErrorBoundary>
            {!files ? (
                <Spinner size={'large'} centered />
            ) : (
                <CSSTransition classNames={'fade'} timeout={150} appear in>
                    <div className={style.list}>
                        <div className={style.list_head}>
                            <div css={tw`flex flex-1 items-center px-4 overflow-hidden`}>
                                <div css={tw`flex-1 pl-16`}>Name</div>
                                <div css={tw`w-1/6 text-right mr-4 hidden sm:block`}>Size</div>
                                <div css={tw`w-1/5 text-right mr-4 hidden md:block`}>Modified</div>
                            </div>
                            <div css={tw`w-12 flex-none`} />
                        </div>
                        {files.length > 250 && (
                            <div css={tw`bg-yellow-400 p-3`}>
                                <p css={tw`text-yellow-900 text-sm text-center`}>
                                    This directory is too large to display in the browser, limiting the output to the
                                    first 250 files.
                                </p>
                            </div>
                        )}
                        {!visible.length ? (
                            <div className={style.empty}>
                                <FontAwesomeIcon icon={faFolderOpen} />
                                {files.length ? 'No files match your search.' : 'This directory seems to be empty.'}
                            </div>
                        ) : (
                            sortFiles(visible.slice(0, 250)).map((file) => <FileObjectRow key={file.key} file={file} />)
                        )}
                    </div>
                </CSSTransition>
            )}
            <MassActionsBar />
        </ServerContentBlock>
    );
};
