import {
    faCog,
    faCube,
    faDatabase,
    faFileAlt,
    faFileArchive,
    faFileAudio,
    faFileCode,
    faFileImage,
    faFileImport,
    faFilePdf,
    faFileVideo,
    faFolder,
    faTerminal,
} from '@fortawesome/free-solid-svg-icons';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';
import { FileObject } from '@/api/server/files/loadDirectory';

const ext = (name: string): string => {
    const i = name.lastIndexOf('.');
    return i <= 0 ? (name.startsWith('.') ? name.slice(1).toLowerCase() : '') : name.slice(i + 1).toLowerCase();
};

const groups: [string[], IconDefinition, string][] = [
    [['js', 'mjs', 'cjs', 'ts', 'tsx', 'jsx', 'py', 'php', 'go', 'rs', 'c', 'cpp', 'h', 'java', 'kt', 'rb', 'lua', 'html', 'css'], faFileCode, '#7dd3fc'],
    [['json', 'yml', 'yaml', 'toml', 'ini', 'cfg', 'conf', 'properties', 'xml', 'env', 'example'], faCog, '#c4b5fd'],
    [['sh', 'bat', 'cmd'], faTerminal, '#4ade80'],
    [['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'ico'], faFileImage, '#4ade80'],
    [['mp4', 'mkv', 'mov', 'webm'], faFileVideo, '#f472b6'],
    [['mp3', 'ogg', 'wav', 'flac'], faFileAudio, '#f472b6'],
    [['pdf'], faFilePdf, '#f87171'],
    [['db', 'sqlite', 'sqlite3', 'sql'], faDatabase, '#fbbf24'],
    [['jar', 'exe', 'dll', 'so'], faCube, '#fb923c'],
];

export const iconFor = (file: FileObject): { icon: IconDefinition; color: string } => {
    if (!file.isFile) return { icon: faFolder, color: '#fbbf24' };
    if (file.isSymlink) return { icon: faFileImport, color: '#a3a3ab' };
    if (file.isArchiveType()) return { icon: faFileArchive, color: '#fb923c' };

    const e = ext(file.name);
    const hit = groups.find(([list]) => list.includes(e));
    return hit ? { icon: hit[1], color: hit[2] } : { icon: faFileAlt, color: '#a3a3ab' };
};
