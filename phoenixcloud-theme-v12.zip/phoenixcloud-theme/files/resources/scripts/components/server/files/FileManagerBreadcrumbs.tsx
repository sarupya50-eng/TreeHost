import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import { NavLink, useLocation } from 'react-router-dom';
import { encodePathSegments, hashToPath } from '@/helpers';
import tw from 'twin.macro';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChevronRight, faHome } from '@fortawesome/free-solid-svg-icons';
import style from './style.module.css';

interface Props {
    renderLeft?: JSX.Element;
    withinFileEditor?: boolean;
    isNewFile?: boolean;
}

export default ({ renderLeft, withinFileEditor, isNewFile }: Props) => {
    const [file, setFile] = useState<string | null>(null);
    const id = ServerContext.useStoreState((state) => state.server.data!.id);
    const directory = ServerContext.useStoreState((state) => state.files.directory);
    const { hash } = useLocation();

    useEffect(() => {
        const path = hashToPath(hash);

        if (withinFileEditor && !isNewFile) {
            const name = path.split('/').pop() || null;
            setFile(name);
        }
    }, [withinFileEditor, isNewFile, hash]);

    const breadcrumbs = (): { name: string; path?: string }[] =>
        directory
            .split('/')
            .filter((directory) => !!directory)
            .map((directory, index, dirs) => {
                if (!withinFileEditor && index === dirs.length - 1) {
                    return { name: directory };
                }

                return { name: directory, path: `/${dirs.slice(0, index + 1).join('/')}` };
            });

    return (
        <div className={style.crumbs}>
            {renderLeft || <div css={tw`w-4`} />}
            <FontAwesomeIcon icon={faHome} css={tw`text-neutral-400 mx-1 text-xs`} />
            <span className={style.current} css={tw`text-neutral-300 font-normal`}>
                home
            </span>
            <FontAwesomeIcon icon={faChevronRight} className={style.sep} />
            <NavLink to={`/server/${id}/files`}>container</NavLink>
            {breadcrumbs().map((crumb, index) => (
                <React.Fragment key={index}>
                    <FontAwesomeIcon icon={faChevronRight} className={style.sep} />
                    {crumb.path ? (
                        <NavLink to={`/server/${id}/files#${encodePathSegments(crumb.path)}`}>{crumb.name}</NavLink>
                    ) : (
                        <span className={style.current}>{crumb.name}</span>
                    )}
                </React.Fragment>
            ))}
            {file && (
                <React.Fragment>
                    <FontAwesomeIcon icon={faChevronRight} className={style.sep} />
                    <span className={style.current}>{file}</span>
                </React.Fragment>
            )}
        </div>
    );
};
