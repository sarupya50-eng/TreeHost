import React, { useEffect, useRef, useState } from 'react';
import { Link, RouteComponentProps } from 'react-router-dom';
import { useStoreState } from 'easy-peasy';
import { Formik, FormikHelpers } from 'formik';
import { object, ref as yupRef, string } from 'yup';
import Reaptcha from 'reaptcha';
import tw from 'twin.macro';
import { faAt, faKey, faUser } from '@fortawesome/free-solid-svg-icons';
import register from '@/api/auth/register';
import login from '@/api/auth/login';
import LoginFormContainer from '@/components/auth/LoginFormContainer';
import Field from '@/components/elements/Field';
import Button from '@/components/elements/Button';
import useFlash from '@/plugins/useFlash';

interface Values {
    nameFirst: string;
    nameLast: string;
    username: string;
    email: string;
    password: string;
    confirm: string;
}

export default ({ history }: RouteComponentProps) => {
    const captcha = useRef<Reaptcha>(null);
    const [token, setToken] = useState('');
    const { clearFlashes, clearAndAddHttpError, addFlash } = useFlash();
    const { enabled: recaptchaEnabled, siteKey } = useStoreState((state) => state.settings.data!.recaptcha);

    useEffect(() => {
        clearFlashes();
    }, []);

    const onSubmit = (values: Values, { setSubmitting }: FormikHelpers<Values>) => {
        clearFlashes();

        if (recaptchaEnabled && !token) {
            captcha.current!.execute().catch((error) => {
                setSubmitting(false);
                clearAndAddHttpError({ error });
            });
            return;
        }

        register({ ...values, recaptchaData: token })
            // Sign straight in. With recaptcha on, the token is already spent, so fall back to the login page.
            .then(() => login({ username: values.username, password: values.password }))
            .then((response) => {
                if (response.complete) {
                    // @ts-expect-error this is valid
                    window.location = response.intended || '/';
                    return;
                }
                history.replace('/auth/login/checkpoint', { token: response.confirmationToken });
            })
            .catch((error) => {
                setToken('');
                if (captcha.current) captcha.current.reset();
                setSubmitting(false);

                const url = error && error.response && error.response.config && error.response.config.url;
                if (url === '/auth/login') {
                    history.replace('/auth/login');
                    setTimeout(
                        () =>
                            addFlash({
                                type: 'success',
                                title: 'Account created',
                                message: 'Your account is ready, sign in.',
                            }),
                        150
                    );
                } else {
                    clearAndAddHttpError({ error });
                }
            });
    };

    return (
        <Formik
            onSubmit={onSubmit}
            initialValues={{ nameFirst: '', nameLast: '', username: '', email: '', password: '', confirm: '' }}
            validationSchema={object().shape({
                nameFirst: string().required('Enter your first name.').max(50),
                nameLast: string().required('Enter your last name.').max(50),
                username: string()
                    .required('Choose a username.')
                    .matches(/^[a-z0-9][\w.-]{1,30}[a-z0-9]$/i, '3-32 characters: letters, numbers, . _ -'),
                email: string().required('Enter your email.').email('Enter a valid email address.'),
                password: string().required('Choose a password.').min(8, 'Use at least 8 characters.'),
                confirm: string()
                    .required('Repeat your password.')
                    .oneOf([yupRef('password')], 'Passwords do not match.'),
            })}
        >
            {({ isSubmitting, setSubmitting, submitForm }) => (
                <LoginFormContainer
                    title={'Create account'}
                    subtitle={'Get your own servers, consoles and files.'}
                    css={tw`w-full flex`}
                >
                    <div css={tw`grid grid-cols-2 gap-4`}>
                        <Field icon={faUser} type={'text'} label={'First name'} name={'nameFirst'} disabled={isSubmitting} autoFocus />
                        <Field type={'text'} label={'Last name'} name={'nameLast'} disabled={isSubmitting} />
                    </div>
                    <div css={tw`mt-5`}>
                        <Field icon={faAt} type={'text'} label={'Username'} name={'username'} disabled={isSubmitting} autoComplete={'username'} />
                    </div>
                    <div css={tw`mt-5`}>
                        <Field type={'email'} label={'Email'} name={'email'} disabled={isSubmitting} autoComplete={'email'} />
                    </div>
                    <div css={tw`mt-5`}>
                        <Field icon={faKey} reveal type={'password'} label={'Password'} name={'password'} disabled={isSubmitting} autoComplete={'new-password'} />
                    </div>
                    <div css={tw`mt-5`}>
                        <Field icon={faKey} type={'password'} label={'Repeat password'} name={'confirm'} disabled={isSubmitting} autoComplete={'new-password'} />
                    </div>
                    <div css={tw`mt-6`}>
                        <Button type={'submit'} size={'xlarge'} isLoading={isSubmitting} disabled={isSubmitting}>
                            Create account
                        </Button>
                    </div>
                    {recaptchaEnabled && (
                        <Reaptcha
                            ref={captcha}
                            size={'invisible'}
                            sitekey={siteKey || '_invalid_key'}
                            onVerify={(response) => {
                                setToken(response);
                                submitForm();
                            }}
                            onExpire={() => {
                                setSubmitting(false);
                                setToken('');
                            }}
                        />
                    )}
                    <p css={tw`mt-6 text-center text-sm text-neutral-400`}>
                        Already have an account?{' '}
                        <Link to={'/auth/login'} css={tw`font-semibold text-primary-300 no-underline hover:text-primary-200`}>
                            Sign in
                        </Link>
                    </p>
                </LoginFormContainer>
            )}
        </Formik>
    );
};
