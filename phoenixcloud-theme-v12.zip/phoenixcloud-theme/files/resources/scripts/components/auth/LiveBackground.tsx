import React, { useEffect, useRef } from 'react';
import { theme } from 'twin.macro';

const A300 = theme`colors.primary.300`.toString();
const A400 = theme`colors.primary.400`.toString();
const A500 = theme`colors.primary.500`.toString();

const rgba = (hex: string, a: number): string => {
    const n = parseInt(hex.replace('#', ''), 16);
    return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
};

interface Ember {
    x: number;
    y: number;
    r: number;
    vy: number;
    vx: number;
    a: number;
    ph: number;
    c: string;
}

const COLORS = [A300, A400, A300, '#ffffff', '#fbbf24'];

// Live background for the sign-in pages: slow-drifting colour glows plus rising embers on a canvas.
export default () => {
    const ref = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = ref.current;
        const ctx = canvas && canvas.getContext('2d');
        if (!canvas || !ctx) return;
        if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        let w = 0;
        let h = 0;
        let raf = 0;
        const embers: Ember[] = [];

        const make = (fromBottom: boolean): Ember => ({
            x: Math.random() * w,
            y: fromBottom ? h + 10 + Math.random() * 40 : Math.random() * h,
            r: 0.8 + Math.random() * 2.2,
            vy: 0.25 + Math.random() * 0.8,
            vx: (Math.random() - 0.5) * 0.25,
            a: 0.35 + Math.random() * 0.6,
            ph: Math.random() * Math.PI * 2,
            c: COLORS[Math.floor(Math.random() * COLORS.length)],
        });

        const resize = () => {
            w = window.innerWidth;
            h = window.innerHeight;
            canvas.width = w * dpr;
            canvas.height = h * dpr;
            canvas.style.width = `${w}px`;
            canvas.style.height = `${h}px`;
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            const count = w < 640 ? 38 : 85;
            while (embers.length < count) embers.push(make(false));
            embers.length = count;
        };
        resize();
        window.addEventListener('resize', resize);

        const frame = (t: number) => {
            raf = requestAnimationFrame(frame);
            if (document.hidden) return;
            ctx.clearRect(0, 0, w, h);
            ctx.globalCompositeOperation = 'lighter';
            for (let i = 0; i < embers.length; i++) {
                const p = embers[i];
                p.y -= p.vy;
                p.x += p.vx + Math.sin(t / 1700 + p.ph) * 0.3;
                if (p.y < -12 || p.x < -12 || p.x > w + 12) embers[i] = make(true);
                const fade = Math.min(1, Math.max(0, p.y / (h * 0.35))); // fade out toward the top
                const alpha = p.a * fade * (0.65 + 0.35 * Math.sin(t / 480 + p.ph));
                const glow = p.r * 7;
                const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, glow);
                g.addColorStop(0, rgba(p.c, alpha));
                g.addColorStop(0.25, rgba(p.c, alpha * 0.35));
                g.addColorStop(1, rgba(p.c, 0));
                ctx.fillStyle = g;
                ctx.beginPath();
                ctx.arc(p.x, p.y, glow, 0, Math.PI * 2);
                ctx.fill();
            }
        };
        raf = requestAnimationFrame(frame);

        return () => {
            cancelAnimationFrame(raf);
            window.removeEventListener('resize', resize);
        };
    }, []);

    return (
        <div className={'pc-live-bg'} aria-hidden>
            <div className={'pc-orb pc-orb-1'} style={{ background: `radial-gradient(circle, ${rgba(A500, 0.45)}, transparent 65%)` }} />
            <div className={'pc-orb pc-orb-2'} style={{ background: `radial-gradient(circle, ${rgba(A300, 0.30)}, transparent 65%)` }} />
            <div className={'pc-orb pc-orb-3'} style={{ background: 'radial-gradient(circle, rgba(251,191,36,0.16), transparent 65%)' }} />
            <canvas ref={ref} />
        </div>
    );
};
