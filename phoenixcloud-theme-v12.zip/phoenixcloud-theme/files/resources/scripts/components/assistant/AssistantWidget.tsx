import React, { useEffect, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { PaperAirplaneIcon, SparklesIcon, TrashIcon, XIcon } from '@heroicons/react/outline';
import styled, { keyframes } from 'styled-components/macro';
import tw, { theme } from 'twin.macro';
import http from '@/api/http';

interface Msg {
    role: 'user' | 'assistant';
    content: string;
    error?: boolean;
}

const KEY = 'pc-ai-chat';
const SUGGESTIONS = [
    'How do I restart my server?',
    'How do I take a backup?',
    'My server will not start',
    'How do I upload files?',
];

const load = (): Msg[] => {
    try {
        const v = JSON.parse(window.sessionStorage.getItem(KEY) || '[]');
        return Array.isArray(v) ? v.slice(-30) : [];
    } catch (e) {
        return [];
    }
};

const bounce = keyframes`
    0%, 80%, 100% { opacity: 0.25; transform: translateY(0); }
    40% { opacity: 1; transform: translateY(-3px); }
`;

const Dot = styled.span<{ d: number }>`
    display: inline-block;
    width: 6px;
    height: 6px;
    margin: 0 2px;
    border-radius: 9999px;
    background: ${theme`colors.primary.300`.toString()};
    animation: ${bounce} 1.1s ${(p) => p.d}s infinite ease-in-out;
`;

const Launcher = styled.button`
    ${tw`fixed right-5 bottom-5 z-40 flex items-center justify-center w-14 h-14 rounded-full border-0 cursor-pointer`};
    color: #0b0b0c;
    background: linear-gradient(135deg, ${theme`colors.primary.300`.toString()}, ${theme`colors.primary.500`.toString()});
    box-shadow: 0 12px 30px -8px ${theme`colors.primary.400`.toString()}, 0 0 0 1px rgba(255, 255, 255, 0.12) inset;
    transition: transform 0.25s cubic-bezier(0.22, 1, 0.36, 1), box-shadow 0.25s ease;

    &:hover {
        transform: translateY(-3px) scale(1.05);
    }
`;

// Tiny renderer: ```code blocks```, `inline code`, **bold**. Everything else stays plain text.
const inline = (text: string, key: string) =>
    text.split(/(`[^`]+`|\*\*[^*]+\*\*)/g).map((part, i) =>
        part.startsWith('`') && part.endsWith('`') && part.length > 2 ? (
            <code
                key={`${key}${i}`}
                className={'px-1.5 py-0.5 rounded-md text-xs'}
                style={{ background: 'rgba(255,255,255,0.08)', color: theme`colors.primary.200`.toString() }}
            >
                {part.slice(1, -1)}
            </code>
        ) : part.startsWith('**') && part.endsWith('**') && part.length > 4 ? (
            <strong key={`${key}${i}`} className={'text-neutral-50'}>
                {part.slice(2, -2)}
            </strong>
        ) : (
            <React.Fragment key={`${key}${i}`}>{part}</React.Fragment>
        )
    );

const Rich = ({ text }: { text: string }) => (
    <>
        {text.split(/```[a-z]*\n?/i).map((chunk, i) =>
            i % 2 === 1 ? (
                <pre
                    key={i}
                    className={'my-2 p-3 rounded-lg text-xs overflow-x-auto'}
                    style={{ background: '#070708', border: '1px solid #26262b' }}
                >
                    {chunk.replace(/\n$/, '')}
                </pre>
            ) : (
                <span key={i} className={'whitespace-pre-wrap break-words'}>
                    {inline(chunk, `c${i}`)}
                </span>
            )
        )}
    </>
);

export default () => {
    const [open, setOpen] = useState(false);
    const [msgs, setMsgs] = useState<Msg[]>(load);
    const [text, setText] = useState('');
    const [busy, setBusy] = useState(false);
    const end = useRef<HTMLDivElement>(null);
    const input = useRef<HTMLTextAreaElement>(null);
    const { pathname } = useLocation();

    useEffect(() => {
        try {
            window.sessionStorage.setItem(KEY, JSON.stringify(msgs.filter((m) => !m.error)));
        } catch (e) {
            /* storage unavailable, chat just won't persist */
        }
    }, [msgs]);

    useEffect(() => {
        if (end.current) end.current.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }, [msgs, busy, open]);

    useEffect(() => {
        if (open && input.current) input.current.focus();
    }, [open]);

    const send = (raw: string) => {
        const content = raw.trim();
        if (!content || busy) return;

        const next: Msg[] = [...msgs.filter((m) => !m.error), { role: 'user', content }];
        setMsgs(next);
        setText('');
        setBusy(true);

        http.post('/api/client/assistant', {
            messages: next.map(({ role, content }) => ({ role, content })),
            page: pathname,
        })
            .then(({ data }) => setMsgs([...next, { role: 'assistant', content: data.reply || '...' }]))
            .catch((err) => {
                const status = err?.response?.status;
                const message =
                    status === 503
                        ? 'The assistant is not set up yet. Ask an admin to add the API key.'
                        : status === 429
                        ? 'Slow down a little, you can send more messages in a minute.'
                        : 'Something went wrong. Please try again.';
                setMsgs([...next, { role: 'assistant', content: message, error: true }]);
            })
            .then(() => setBusy(false));
    };

    return (
        <>
            {!open && (
                <Launcher onClick={() => setOpen(true)} title={'PhoenixCloud AI'} aria-label={'Open AI assistant'}>
                    <SparklesIcon className={'w-6 h-6'} strokeWidth={1.8} />
                </Launcher>
            )}
            {open && (
                <div
                    className={'pc-fade fixed z-40 flex flex-col right-0 bottom-0 sm:right-5 sm:bottom-5'}
                    style={{
                        width: 'min(400px, 100vw)',
                        height: 'min(580px, calc(100vh - 2rem))',
                        background: '#0e0e10',
                        border: '1px solid #26262b',
                        borderRadius: 18,
                        boxShadow: '0 30px 70px -20px rgba(0,0,0,0.95), inset 0 1px 0 rgba(255,255,255,0.05)',
                    }}
                >
                    <div
                        className={'flex items-center flex-none px-4 py-3'}
                        style={{ borderBottom: '1px solid #1c1c20', background: '#141416', borderRadius: '18px 18px 0 0' }}
                    >
                        <span
                            className={'flex items-center justify-center w-9 h-9 rounded-xl mr-3 flex-none'}
                            style={{
                                color: '#0b0b0c',
                                background: `linear-gradient(135deg, ${theme`colors.primary.300`.toString()}, ${theme`colors.primary.500`.toString()})`,
                            }}
                        >
                            <SparklesIcon className={'w-5 h-5'} strokeWidth={1.8} />
                        </span>
                        <div className={'flex-1 min-w-0'}>
                            <p className={'text-sm font-semibold text-neutral-50 leading-tight'}>PhoenixCloud AI</p>
                            <p className={'text-xs text-neutral-400 leading-tight mt-0.5'}>Ask anything about your server</p>
                        </div>
                        {msgs.length > 0 && (
                            <button
                                title={'Clear chat'}
                                onClick={() => setMsgs([])}
                                className={'p-2 text-neutral-400 hover:text-neutral-50'}
                            >
                                <TrashIcon className={'w-4 h-4'} />
                            </button>
                        )}
                        <button
                            title={'Close'}
                            onClick={() => setOpen(false)}
                            className={'p-2 text-neutral-400 hover:text-neutral-50'}
                        >
                            <XIcon className={'w-5 h-5'} />
                        </button>
                    </div>

                    <div className={'flex-1 overflow-y-auto px-4 py-4 space-y-3'}>
                        {msgs.length === 0 && (
                            <div className={'pc-fade text-center pt-6'}>
                                <p className={'text-neutral-50 font-semibold'}>Hi, how can I help?</p>
                                <p className={'text-xs text-neutral-400 mt-1 mb-5'}>
                                    I can explain the panel and help fix common problems.
                                </p>
                                <div className={'flex flex-wrap justify-center gap-2'}>
                                    {SUGGESTIONS.map((s) => (
                                        <button
                                            key={s}
                                            onClick={() => send(s)}
                                            className={'px-3 py-1.5 rounded-full text-xs text-neutral-200 hover:text-neutral-50'}
                                            style={{ background: '#141416', border: '1px solid #26262b' }}
                                        >
                                            {s}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}
                        {msgs.map((m, i) => (
                            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                <div
                                    className={'px-3.5 py-2.5 text-sm leading-relaxed max-w-[85%]'}
                                    style={
                                        m.role === 'user'
                                            ? {
                                                  color: '#0b0b0c',
                                                  background: `linear-gradient(135deg, ${theme`colors.primary.300`.toString()}, ${theme`colors.primary.400`.toString()})`,
                                                  borderRadius: '16px 16px 4px 16px',
                                              }
                                            : {
                                                  color: m.error ? '#fca5a5' : '#e6e6e8',
                                                  background: '#17171a',
                                                  border: '1px solid #232328',
                                                  borderRadius: '16px 16px 16px 4px',
                                              }
                                    }
                                >
                                    {m.role === 'user' ? <span className={'whitespace-pre-wrap break-words'}>{m.content}</span> : <Rich text={m.content} />}
                                </div>
                            </div>
                        ))}
                        {busy && (
                            <div className={'flex justify-start'}>
                                <div
                                    className={'px-3.5 py-3'}
                                    style={{ background: '#17171a', border: '1px solid #232328', borderRadius: '16px 16px 16px 4px' }}
                                >
                                    <Dot d={0} />
                                    <Dot d={0.15} />
                                    <Dot d={0.3} />
                                </div>
                            </div>
                        )}
                        <div ref={end} />
                    </div>

                    <form
                        className={'flex items-end flex-none gap-2 p-3'}
                        style={{ borderTop: '1px solid #1c1c20' }}
                        onSubmit={(e) => {
                            e.preventDefault();
                            send(text);
                        }}
                    >
                        <textarea
                            ref={input}
                            value={text}
                            rows={1}
                            maxLength={2000}
                            placeholder={'Type your question...'}
                            onChange={(e) => setText(e.currentTarget.value)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                    e.preventDefault();
                                    send(text);
                                }
                            }}
                            className={'flex-1 resize-none text-sm text-neutral-100 px-3 py-2.5 rounded-xl'}
                            style={{ background: '#0b0b0c', border: '1px solid #26262b', outline: 'none', maxHeight: 110 }}
                        />
                        <button
                            type={'submit'}
                            disabled={busy || !text.trim()}
                            className={'flex items-center justify-center w-10 h-10 rounded-xl flex-none disabled:opacity-40'}
                            style={{
                                color: '#0b0b0c',
                                background: `linear-gradient(135deg, ${theme`colors.primary.300`.toString()}, ${theme`colors.primary.500`.toString()})`,
                            }}
                        >
                            <PaperAirplaneIcon className={'w-5 h-5'} style={{ transform: 'rotate(90deg)' }} />
                        </button>
                    </form>
                    <p className={'text-center text-2xs text-neutral-500 pb-2'}>AI can make mistakes. Check important steps.</p>
                </div>
            )}
        </>
    );
};
