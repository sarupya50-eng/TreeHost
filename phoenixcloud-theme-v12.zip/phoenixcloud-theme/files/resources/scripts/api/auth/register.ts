import http from '@/api/http';

export interface RegisterData {
    username: string;
    email: string;
    nameFirst: string;
    nameLast: string;
    password: string;
    recaptchaData?: string | null;
}

export default ({ username, email, nameFirst, nameLast, password, recaptchaData }: RegisterData): Promise<void> =>
    new Promise((resolve, reject) => {
        http.get('/sanctum/csrf-cookie')
            .then(() =>
                http.post('/auth/register', {
                    username,
                    email,
                    name_first: nameFirst,
                    name_last: nameLast,
                    password,
                    password_confirmation: password,
                    'g-recaptcha-response': recaptchaData,
                })
            )
            .then(() => resolve())
            .catch(reject);
    });
