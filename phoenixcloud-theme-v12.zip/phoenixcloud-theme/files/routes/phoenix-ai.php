<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Api\Client;

// Loaded from routes/api-client.php, so it inherits the /api/client prefix and auth middleware.
Route::post('/assistant', [Client\AssistantController::class, 'chat'])->middleware('throttle:15,1');
