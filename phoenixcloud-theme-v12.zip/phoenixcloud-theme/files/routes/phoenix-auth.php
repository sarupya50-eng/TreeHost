<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Auth;

// Loaded from routes/auth.php, so it inherits the /auth prefix and guest middleware.
Route::get('/register', [Auth\LoginController::class, 'index'])->name('auth.register');
Route::post('/register', Auth\RegisterController::class)->middleware(['throttle:10,60', 'recaptcha']);
