# PhoenixCloud theme for Pterodactyl 1.15.x
Navy + ice-blue skin with a left sidebar layout: login, dashboard, server pages, console, buttons, inputs, admin area.
Prebuilt, so no Node or yarn is needed on the server.

    unzip phoenixcloud-theme.zip && cd phoenixcloud-theme
    sudo bash install.sh

A backup is saved to ~/phoenixcloud-backup-*. Undo command is printed at the end.

Colors live in `files/tailwind.config.js` (the `gray` object) and `files/public/themes/pterodactyl/css/phoenixcloud-admin.css`.
Changing frontend source needs: `yarn install && yarn build:production` in /var/www/pterodactyl.

Notice banner text and dashboard quick-link cards: edit `files/resources/scripts/phoenix.config.ts`
(then rebuild: copy to the panel, `yarn install && yarn build:production`), or ask for a rebuilt zip.
