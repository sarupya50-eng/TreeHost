import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBullhorn, faTimes } from '@fortawesome/free-solid-svg-icons';
import { usePersistedState } from '@/plugins/usePersistedState';
import phoenix from '@/phoenix.config';

export default ({ className }: { className?: string }) => {
    const { title, text } = phoenix.notice;
    const key = `pc:notice:${text}`;
    const [dismissed, setDismissed] = usePersistedState<boolean>(key, false);

    if (!text || dismissed) return null;

    return (
        <div
            className={`relative flex items-start rounded-xl border border-sky-400 border-opacity-40 p-4 pr-10 ${
                className || ''
            }`}
            style={{ background: 'linear-gradient(90deg, rgba(56,189,248,0.16), rgba(56,189,248,0.04))' }}
        >
            <FontAwesomeIcon icon={faBullhorn} className={'text-sky-300 mt-1 mr-3'} />
            <div>
                <p className={'font-semibold text-sky-100 text-sm'}>{title}</p>
                <p className={'text-sm text-neutral-200'}>{text}</p>
            </div>
            <button
                onClick={() => setDismissed(true)}
                className={'absolute top-3 right-3 text-neutral-300 hover:text-white'}
                title={'Dismiss'}
            >
                <FontAwesomeIcon icon={faTimes} />
            </button>
        </div>
    );
};
