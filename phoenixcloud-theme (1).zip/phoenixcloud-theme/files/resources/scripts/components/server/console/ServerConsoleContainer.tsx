import React, { memo } from 'react';
import { ServerContext } from '@/state/server';
import Can from '@/components/elements/Can';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import isEqual from 'react-fast-compare';
import Spinner from '@/components/elements/Spinner';
import Features from '@feature/Features';
import Console from '@/components/server/console/Console';
import StatGraphs from '@/components/server/console/StatGraphs';
import PowerButtons from '@/components/server/console/PowerButtons';
import ServerDetailsBlock from '@/components/server/console/ServerDetailsBlock';
import { Alert } from '@/components/elements/alert';
import NoticeBanner from '@/components/layout/NoticeBanner';
import BackupBar from '@/components/server/console/BackupBar';

export type PowerAction = 'start' | 'stop' | 'restart' | 'kill';

const ServerConsoleContainer = () => {
    const name = ServerContext.useStoreState((state) => state.server.data!.name);
    const description = ServerContext.useStoreState((state) => state.server.data!.description);
    const node = ServerContext.useStoreState((state) => state.server.data!.node);
    const status = ServerContext.useStoreState((state) => state.status.value);
    const isInstalling = ServerContext.useStoreState((state) => state.server.isInstalling);
    const isTransferring = ServerContext.useStoreState((state) => state.server.data!.isTransferring);
    const eggFeatures = ServerContext.useStoreState((state) => state.server.data!.eggFeatures, isEqual);
    const isNodeUnderMaintenance = ServerContext.useStoreState((state) => state.server.data!.isNodeUnderMaintenance);

    return (
        <ServerContentBlock title={'Console'}>
            {(isNodeUnderMaintenance || isInstalling || isTransferring) && (
                <Alert type={'warning'} className={'mb-4'}>
                    {isNodeUnderMaintenance
                        ? 'The node of this server is currently under maintenance and all actions are unavailable.'
                        : isInstalling
                        ? 'This server is currently running its installation process and most actions are unavailable.'
                        : 'This server is currently being transferred to another node and all actions are unavailable.'}
                </Alert>
            )}
            <div className={'pc-card pc-fade rounded-2xl p-5 mb-4'}>
                <div className={'flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4'}>
                    <div className={'min-w-0'}>
                        <div className={'flex items-center gap-3'}>
                            <h1 className={'font-header font-semibold text-2xl text-gray-50 truncate'}>{name}</h1>
                            <span
                                className={`flex-none text-2xs font-semibold uppercase tracking-wider rounded-full px-2 py-0.5 border ${
                                    status === 'running'
                                        ? 'text-green-300 border-green-400 bg-green-500 bg-opacity-10'
                                        : status === 'offline' || !status
                                        ? 'text-red-300 border-red-400 bg-red-500 bg-opacity-10'
                                        : 'text-yellow-300 border-yellow-400 bg-yellow-500 bg-opacity-10'
                                }`}
                            >
                                {status || 'offline'}
                            </span>
                        </div>
                        <p className={'text-sm text-gray-300 mt-1 truncate'}>
                            {description || node}
                            {description && <span className={'text-gray-400'}> &middot; {node}</span>}
                        </p>
                    </div>
                    <Can action={['control.start', 'control.stop', 'control.restart']} matchAny>
                        <PowerButtons className={'flex sm:justify-end space-x-2'} />
                    </Can>
                </div>
            </div>
            <NoticeBanner className={'mb-4 pc-fade-2'} />
            <BackupBar className={'mb-4 pc-fade-2'} />
            <div className={'grid grid-cols-4 gap-2 sm:gap-4 mb-4'}>
                <div className={'flex col-span-4 lg:col-span-3 min-w-0'}>
                    <Spinner.Suspense>
                        <Console />
                    </Spinner.Suspense>
                </div>
                <ServerDetailsBlock className={'col-span-4 lg:col-span-1'} />
            </div>
            <div className={'grid grid-cols-1 md:grid-cols-3 gap-2 sm:gap-4'}>
                <Spinner.Suspense>
                    <StatGraphs />
                </Spinner.Suspense>
            </div>
            <Features enabled={eggFeatures} />
        </ServerContentBlock>
    );
};

export default memo(ServerConsoleContainer, isEqual);
