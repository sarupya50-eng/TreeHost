import React, { useEffect, useRef, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faServer, faSlidersH } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import { Server } from '@/api/server/getServer';
import getServerResourceUsage, { ServerPowerState, ServerStats } from '@/api/server/getServerResourceUsage';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import tw from 'twin.macro';
import GreyRowBox from '@/components/elements/GreyRowBox';
import Spinner from '@/components/elements/Spinner';
import styled from 'styled-components/macro';

// Determines if the current value is in an alarm threshold so we can show it in red rather
// than the more faded default style.
const isAlarmState = (current: number, limit: number): boolean => limit > 0 && current / (limit * 1024 * 1024) >= 0.9;

const StatusIndicatorBox = styled(GreyRowBox)<{ $status: ServerPowerState | undefined }>`
    ${tw`grid grid-cols-12 gap-4 relative`};
    ${({ $status }) =>
        $status === 'running'
            ? tw`border-green-500 border-opacity-30`
            : $status === 'offline'
            ? tw`border-red-500 border-opacity-20`
            : ''};
`;

type Timer = ReturnType<typeof setInterval>;

export default ({ server, className }: { server: Server; className?: string }) => {
    const interval = useRef<Timer>(null) as React.MutableRefObject<Timer>;
    const [isSuspended, setIsSuspended] = useState(server.status === 'suspended');
    const [stats, setStats] = useState<ServerStats | null>(null);

    const getStats = () =>
        getServerResourceUsage(server.uuid)
            .then((data) => setStats(data))
            .catch((error) => console.error(error));

    useEffect(() => {
        setIsSuspended(stats?.isSuspended || server.status === 'suspended');
    }, [stats?.isSuspended, server.status]);

    useEffect(() => {
        // Don't waste a HTTP request if there is nothing important to show to the user because
        // the server is suspended.
        if (isSuspended || server.isNodeUnderMaintenance) return;

        getStats().then(() => {
            interval.current = setInterval(() => getStats(), 30000);
        });

        return () => {
            interval.current && clearInterval(interval.current);
        };
    }, [isSuspended, server.isNodeUnderMaintenance]);

    const alarms = { cpu: false, memory: false, disk: false };
    if (stats) {
        alarms.cpu = server.limits.cpu === 0 ? false : stats.cpuUsagePercent >= server.limits.cpu * 0.9;
        alarms.memory = isAlarmState(stats.memoryUsageInBytes, server.limits.memory);
        alarms.disk = server.limits.disk === 0 ? false : isAlarmState(stats.diskUsageInBytes, server.limits.disk);
    }

    const diskLimit = server.limits.disk !== 0 ? bytesToString(mbToBytes(server.limits.disk)) : 'Unlimited';
    const memoryLimit = server.limits.memory !== 0 ? bytesToString(mbToBytes(server.limits.memory)) : 'Unlimited';
    const cpuLimit = server.limits.cpu !== 0 ? server.limits.cpu + ' %' : 'Unlimited';

    const statusClass =
        isSuspended || stats?.status === 'offline'
            ? 'bg-red-500'
            : stats?.status === 'running'
            ? 'bg-green-400'
            : stats?.status
            ? 'bg-yellow-400'
            : 'bg-neutral-400';
    const address = server.allocations.filter((alloc) => alloc.isDefault)[0];

    const Metric = ({
        label,
        value,
        limit,
        alarm,
    }: {
        label: string;
        value: string;
        limit: string;
        alarm: boolean;
    }) => (
        <div css={tw`min-w-0`}>
            <p css={tw`text-2xs uppercase tracking-wider text-neutral-400`}>{label}</p>
            <p css={tw`text-sm font-semibold whitespace-nowrap`} className={alarm ? 'text-red-400' : 'text-neutral-50'}>
                {value}
            </p>
            <p css={tw`text-2xs text-neutral-400 whitespace-nowrap`}>of {limit}</p>
        </div>
    );

    return (
        <StatusIndicatorBox as={Link} to={`/server/${server.id}`} className={className} $status={stats?.status}>
            <div css={tw`flex items-center col-span-12 lg:col-span-5 min-w-0`}>
                <span
                    className={`inline-block w-2.5 h-2.5 rounded-full mr-4 flex-none ${statusClass} ${
                        stats?.status === 'running' ? 'pc-live' : ''
                    }`}
                />
                <div className={'icon mr-4'}>
                    <FontAwesomeIcon icon={faServer} />
                </div>
                <div css={tw`min-w-0`}>
                    <p css={tw`text-base font-semibold text-neutral-50 truncate`}>{server.name}</p>
                    <p css={tw`text-xs text-neutral-400 truncate`}>
                        {address ? (
                            <span className={'pc-reveal'} tabIndex={0}>
                                {address.alias || ip(address.ip)}:{address.port}
                            </span>
                        ) : (
                            server.description
                        )}
                    </p>
                </div>
            </div>
            <div css={tw`hidden lg:grid grid-cols-3 col-span-5 items-center gap-4`}>
                {!stats || isSuspended || server.isNodeUnderMaintenance ? (
                    isSuspended ? (
                        <span css={tw`bg-red-500 rounded px-2 py-1 text-red-100 text-xs`}>
                            {server.status === 'suspended' ? 'Suspended' : 'Connection Error'}
                        </span>
                    ) : server.isNodeUnderMaintenance ? (
                        <span css={tw`bg-yellow-500 rounded px-2 py-1 text-yellow-100 text-xs`}>Under Maintenance</span>
                    ) : server.isTransferring || server.status ? (
                        <span css={tw`bg-neutral-500 rounded px-2 py-1 text-neutral-100 text-xs`}>
                            {server.isTransferring
                                ? 'Transferring'
                                : server.status === 'installing'
                                ? 'Installing'
                                : server.status === 'restoring_backup'
                                ? 'Restoring Backup'
                                : 'Unavailable'}
                        </span>
                    ) : (
                        <Spinner size={'small'} />
                    )
                ) : (
                    <>
                        <Metric
                            label={'Memory'}
                            value={bytesToString(stats.memoryUsageInBytes)}
                            limit={memoryLimit}
                            alarm={alarms.memory}
                        />
                        <Metric
                            label={'Disk'}
                            value={bytesToString(stats.diskUsageInBytes)}
                            limit={diskLimit}
                            alarm={alarms.disk}
                        />
                        <Metric
                            label={'CPU'}
                            value={`${stats.cpuUsagePercent.toFixed(1)}%`}
                            limit={cpuLimit}
                            alarm={alarms.cpu}
                        />
                    </>
                )}
            </div>
            <div css={tw`hidden sm:flex col-span-12 lg:col-span-2 justify-end`}>
                <span
                    css={tw`inline-flex items-center rounded-lg px-4 py-2 text-sm font-semibold text-neutral-900 bg-sky-400`}
                    className={'transition-colors duration-200 group-hover:bg-sky-300'}
                >
                    Manage
                    <FontAwesomeIcon icon={faSlidersH} css={tw`ml-2 text-xs`} />
                </span>
            </div>
        </StatusIndicatorBox>
    );
};
