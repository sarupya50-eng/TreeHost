import React, { useEffect, useState } from 'react';
import { Server } from '@/api/server/getServer';
import getServers from '@/api/getServers';
import ServerRow from '@/components/dashboard/ServerRow';
import Spinner from '@/components/elements/Spinner';
import PageContentBlock from '@/components/elements/PageContentBlock';
import useFlash from '@/plugins/useFlash';
import { useStoreState } from 'easy-peasy';
import { usePersistedState } from '@/plugins/usePersistedState';
import Switch from '@/components/elements/Switch';
import tw from 'twin.macro';
import useSWR from 'swr';
import { PaginatedResult } from '@/api/http';
import Pagination from '@/components/elements/Pagination';
import { useLocation } from 'react-router-dom';
import NoticeBanner from '@/components/layout/NoticeBanner';
import phoenix from '@/phoenix.config';
import RecentActivity from '@/components/dashboard/RecentActivity';

export default () => {
    const { search } = useLocation();
    const defaultPage = Number(new URLSearchParams(search).get('page') || '1');

    const [page, setPage] = useState(!isNaN(defaultPage) && defaultPage > 0 ? defaultPage : 1);
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const uuid = useStoreState((state) => state.user.data!.uuid);
    const username = useStoreState((state) => state.user.data!.username);
    const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);
    const [showOnlyAdmin, setShowOnlyAdmin] = usePersistedState(`${uuid}:show_all_servers`, false);

    const { data: servers, error } = useSWR<PaginatedResult<Server>>(
        ['/api/client/servers', showOnlyAdmin && rootAdmin, page],
        () => getServers({ page, type: showOnlyAdmin && rootAdmin ? 'admin' : undefined })
    );

    useEffect(() => {
        setPage(1);
    }, [showOnlyAdmin]);

    useEffect(() => {
        if (!servers) return;
        if (servers.pagination.currentPage > 1 && !servers.items.length) {
            setPage(1);
        }
    }, [servers?.pagination.currentPage]);

    useEffect(() => {
        // Don't use react-router to handle changing this part of the URL, otherwise it
        // triggers a needless re-render. We just want to track this in the URL incase the
        // user refreshes the page.
        window.history.replaceState(null, document.title, `/${page <= 1 ? '' : `?page=${page}`}`);
    }, [page]);

    useEffect(() => {
        if (error) clearAndAddHttpError({ key: 'dashboard', error });
        if (!error) clearFlashes('dashboard');
    }, [error]);

    return (
        <PageContentBlock title={'Dashboard'} showFlashKey={'dashboard'}>
            <div css={tw`mb-6`}>
                <h1 css={tw`text-3xl font-semibold text-neutral-100`}>Welcome back, {username}</h1>
                <p css={tw`text-neutral-300 mt-1`}>Manage all your instances here.</p>
            </div>
            <NoticeBanner className={'mb-6'} />
            {phoenix.links.some((l) => l.url) && (
                <div className={'grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-8'}>
                    {phoenix.links
                        .filter((l) => l.url)
                        .map((l, i) => (
                            <a
                                key={l.title}
                                href={l.url}
                                target={'_blank'}
                                rel={'noreferrer noopener'}
                                className={`block rounded-xl border p-5 no-underline pc-lift pc-fade-${Math.min(
                                    i + 2,
                                    4
                                )} ${
                                    i === 0 ? 'border-sky-300 border-opacity-50' : 'border-neutral-600 bg-neutral-700'
                                }`}
                                style={
                                    i === 0
                                        ? { background: 'linear-gradient(135deg, #7dd3fc 0%, #0284c7 100%)' }
                                        : undefined
                                }
                            >
                                <p className={`text-xs ${i === 0 ? 'text-sky-50' : 'text-neutral-300'}`}>{l.blurb}</p>
                                <p className={'text-xl font-semibold text-white mt-2'}>{l.title}</p>
                                <p className={`text-xs mt-3 ${i === 0 ? 'text-sky-50' : 'text-sky-300'}`}>
                                    Visit &rsaquo;
                                </p>
                            </a>
                        ))}
                </div>
            )}
            <div className={'grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_320px] gap-6 items-start'}>
                <div>
                    <h2 css={tw`text-lg font-semibold text-neutral-100 mb-1`}>Your servers</h2>
                    <p css={tw`text-sm text-neutral-400 mb-3`}>Everything on this account, with live usage.</p>
                    {rootAdmin && (
                        <div css={tw`mb-2 flex justify-end items-center`}>
                            <p css={tw`uppercase text-xs text-neutral-400 mr-2`}>
                                {showOnlyAdmin ? "Showing others' servers" : 'Showing your servers'}
                            </p>
                            <Switch
                                name={'show_all_servers'}
                                defaultChecked={showOnlyAdmin}
                                onChange={() => setShowOnlyAdmin((s) => !s)}
                            />
                        </div>
                    )}
                    {!servers ? (
                        <Spinner centered size={'large'} />
                    ) : (
                        <Pagination data={servers} onPageSelect={setPage}>
                            {({ items }) =>
                                items.length > 0 ? (
                                    items.map((server, index) => (
                                        <ServerRow
                                            key={server.uuid}
                                            server={server}
                                            css={index > 0 ? tw`mt-2` : undefined}
                                        />
                                    ))
                                ) : (
                                    <p css={tw`text-center text-sm text-neutral-400`}>
                                        {showOnlyAdmin
                                            ? 'There are no other servers to display.'
                                            : 'There are no servers associated with your account.'}
                                    </p>
                                )
                            }
                        </Pagination>
                    )}
                </div>
                <RecentActivity />
            </div>
        </PageContentBlock>
    );
};
