// PhoenixCloud front-end settings. Edit, then rebuild (yarn build:production).
// Leave a link's `url` empty to hide that card.
export default {
    // Dismissible banner shown on the dashboard and server console. Empty text = hidden.
    notice: {
        title: 'Important!',
        text: 'Always keep a backup of your server. Open the Backups section to create one.',
    },
    // Quick-link cards on the dashboard.
    links: [
        { title: 'Discord', blurb: 'Get help and talk to the community.', url: 'https://discord.gg/eX2URsJJ3b' },
        { title: 'Billing', blurb: 'Invoices, plans and payment.', url: 'https://dash.phoenixcloud.bond' },
        { title: 'Website', blurb: 'Our main website.', url: 'https://pheonixcloud.space/' },
        { title: 'Contact support', blurb: 'Open a ticket with our team.', url: 'https://discord.gg/eX2URsJJ3b' },
    ],
};
