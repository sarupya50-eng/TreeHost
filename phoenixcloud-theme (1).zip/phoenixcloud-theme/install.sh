#!/usr/bin/env bash
# PhoenixCloud theme for Pterodactyl Panel 1.15.x  (prebuilt - no Node/yarn needed)
set -euo pipefail
PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

[[ $EUID -eq 0 ]] || { echo "Run as root: sudo bash install.sh"; exit 1; }
[[ -f "$PANEL_DIR/artisan" ]] || { echo "No Pterodactyl panel at $PANEL_DIR (set PANEL_DIR=...)"; exit 1; }
VER="$(grep -oP "'version' => '\K[^']+" "$PANEL_DIR/config/app.php" || true)"
echo "Panel version: ${VER:-unknown} (theme built for 1.15.x)"
[[ "$VER" == 1.15.* ]] || { read -r -p "Version differs. Continue anyway? [y/N] " a; [[ "${a,,}" == y* ]] || exit 1; }

BK="$HOME/phoenixcloud-backup-$(date -u +%Y%m%d-%H%M%S)"
mkdir -p "$BK"
echo "Backing up to $BK"
tar czf "$BK/panel-files.tar.gz" -C "$PANEL_DIR" public/assets public/themes public/favicons resources tailwind.config.js

cd "$PANEL_DIR"
php artisan down || true
find public/assets -maxdepth 1 -type f -delete
cp -a "$HERE/files/." "$PANEL_DIR/"

WEB_USER="$(stat -c '%U' "$PANEL_DIR/storage")"; WEB_GROUP="$(stat -c '%G' "$PANEL_DIR/storage")"
chown -R "$WEB_USER:$WEB_GROUP" public resources tailwind.config.js
php artisan view:clear
php artisan config:clear
php artisan up
echo
echo "PhoenixCloud theme installed. Hard-refresh the browser (Ctrl+Shift+R)."
echo "To undo: tar xzf $BK/panel-files.tar.gz -C $PANEL_DIR && php artisan view:clear"
