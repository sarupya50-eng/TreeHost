import React, { forwardRef } from 'react';
import { Form } from 'formik';
import styled from 'styled-components/macro';
import FlashMessageRender from '@/components/FlashMessageRender';
import tw from 'twin.macro';
import { useStoreState } from 'easy-peasy';

type Props = React.DetailedHTMLProps<React.FormHTMLAttributes<HTMLFormElement>, HTMLFormElement> & {
    title?: string;
    subtitle?: string;
};

const Container = styled.div`
    ${tw`w-full mx-auto px-4`};
    max-width: 460px;
    margin-top: 8vh;
`;

export default forwardRef<HTMLFormElement, Props>(({ title, subtitle, ...props }, ref) => {
    const name = useStoreState((state) => state.settings.data!.name);

    return (
        <Container>
            <Form {...props} ref={ref}>
                <div
                    css={tw`w-full rounded-2xl border border-neutral-600 bg-neutral-700 p-8 shadow-2xl`}
                    style={{ background: 'linear-gradient(160deg, rgba(17,35,66,0.97), rgba(6,14,34,0.97))' }}
                >
                    <div css={tw`flex items-center mb-8`}>
                        <img
                            src={'/assets/phoenixcloud-logo.png'}
                            alt={''}
                            css={tw`w-11 h-11 rounded-xl border border-neutral-600`}
                        />
                        <span css={tw`ml-3 text-2xl font-semibold text-neutral-100 tracking-wide`}>
                            Phoenix<span css={tw`text-sky-400`}>Cloud</span>
                        </span>
                    </div>
                    {title && <h2 css={tw`text-3xl font-bold text-neutral-50`}>{title}</h2>}
                    {subtitle && <p css={tw`text-sm text-neutral-300 mt-1`}>{subtitle}</p>}
                    <FlashMessageRender css={tw`mt-4`} />
                    <div css={tw`mt-6 w-full`}>{props.children}</div>
                </div>
            </Form>
            <p css={tw`text-center text-neutral-400 text-xs mt-6`}>
                &copy; {new Date().getFullYear()}&nbsp;{name} &middot; Powered by Pterodactyl
            </p>
        </Container>
    );
});
