import styled from 'styled-components/macro';
import tw from 'twin.macro';

export default styled.div<{ $hoverable?: boolean }>`
    ${tw`flex rounded-xl no-underline text-neutral-200 items-center p-4 border border-neutral-600 transition-all duration-200 overflow-hidden`};

    background: linear-gradient(135deg, rgba(17, 35, 66, 0.9), rgba(10, 22, 48, 0.9));
    backdrop-filter: blur(6px);

    ${(props) => props.$hoverable !== false && tw`hover:border-sky-400`};

    & .icon {
        ${tw`rounded-full w-16 flex items-center justify-center p-3 text-sky-300`};
        background: rgba(56, 189, 248, 0.12);
    }
`;
