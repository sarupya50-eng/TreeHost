import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IconDefinition } from '@fortawesome/free-solid-svg-icons';
import classNames from 'classnames';
import CopyOnClick from '@/components/elements/CopyOnClick';

interface StatBlockProps {
    title: string;
    copyOnClick?: string;
    color?: string | undefined;
    icon: IconDefinition;
    children: React.ReactNode;
    className?: string;
}

// Compact stat tile. `color` (e.g. bg-red-500) draws a warning rail on the left edge.
export default ({ title, copyOnClick, icon, color, className, children }: StatBlockProps) => (
    <CopyOnClick text={copyOnClick}>
        <div
            className={classNames(
                'relative overflow-hidden rounded-xl border border-gray-600 bg-gray-700 px-4 py-3 transition-colors duration-150 hover:border-sky-400',
                className
            )}
        >
            {color && color !== 'bg-gray-700' && (
                <div className={classNames('absolute left-0 top-3 bottom-3 w-1 rounded-r', color)} />
            )}
            <p className={'flex items-center text-xs uppercase tracking-wider text-gray-300'}>
                <FontAwesomeIcon icon={icon} className={'mr-2 text-sky-300'} />
                {title}
            </p>
            <div className={'mt-1 text-lg font-semibold text-gray-50 truncate'}>{children}</div>
        </div>
    </CopyOnClick>
);
