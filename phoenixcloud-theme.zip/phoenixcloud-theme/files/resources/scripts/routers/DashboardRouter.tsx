import React from 'react';
import { Route, Switch } from 'react-router-dom';
import { faCogs, faEye, faKey, faLayerGroup, faTerminal, faUser } from '@fortawesome/free-solid-svg-icons';
import { useStoreState } from 'easy-peasy';
import Shell, { SideHeading, SideLink } from '@/components/layout/Shell';
import DashboardContainer from '@/components/dashboard/DashboardContainer';
import { NotFound } from '@/components/elements/ScreenBlock';
import TransitionRouter from '@/TransitionRouter';
import { useLocation } from 'react-router';
import Spinner from '@/components/elements/Spinner';
import routes from '@/routers/routes';

const accountIcons = [faUser, faKey, faTerminal, faEye];

export default () => {
    const location = useLocation();
    const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);

    const nav = (
        <>
            <SideLink to={'/'} exact label={'Dashboard'} icon={faLayerGroup} />
            <SideHeading>Account</SideHeading>
            {routes.account
                .filter((route) => !!route.name)
                .map(({ path, name, exact = false }, i) => (
                    <SideLink
                        key={path}
                        to={`/account/${path}`.replace('//', '/')}
                        exact={exact}
                        label={name!}
                        icon={accountIcons[i] || faUser}
                    />
                ))}
            {rootAdmin && (
                <>
                    <SideHeading>Staff</SideHeading>
                    <SideLink to={'/admin'} label={'Admin Panel'} icon={faCogs} external />
                </>
            )}
        </>
    );

    return (
        <Shell nav={nav}>
            <TransitionRouter>
                <React.Suspense fallback={<Spinner centered />}>
                    <Switch location={location}>
                        <Route path={'/'} exact>
                            <DashboardContainer />
                        </Route>
                        {routes.account.map(({ path, component: Component }) => (
                            <Route key={path} path={`/account/${path}`.replace('//', '/')} exact>
                                <Component />
                            </Route>
                        ))}
                        <Route path={'*'}>
                            <NotFound />
                        </Route>
                    </Switch>
                </React.Suspense>
            </TransitionRouter>
        </Shell>
    );
};
