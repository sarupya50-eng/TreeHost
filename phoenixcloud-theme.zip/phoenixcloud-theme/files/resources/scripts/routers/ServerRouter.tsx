import TransferListener from '@/components/server/TransferListener';
import React, { useEffect, useState } from 'react';
import { Link, Route, Switch, useRouteMatch } from 'react-router-dom';
import Shell, { SideHeading, SideLink } from '@/components/layout/Shell';
import TransitionRouter from '@/TransitionRouter';
import WebsocketHandler from '@/components/server/WebsocketHandler';
import { ServerContext } from '@/state/server';
import Can from '@/components/elements/Can';
import Spinner from '@/components/elements/Spinner';
import { NotFound, ServerError } from '@/components/elements/ScreenBlock';
import { httpErrorToHuman } from '@/api/http';
import { useStoreState } from 'easy-peasy';
import InstallListener from '@/components/server/InstallListener';
import ErrorBoundary from '@/components/elements/ErrorBoundary';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    IconDefinition,
    faArrowLeft,
    faClock,
    faCloudDownloadAlt,
    faCog,
    faCogs,
    faDatabase,
    faEye,
    faFolderOpen,
    faNetworkWired,
    faPlay,
    faTerminal,
    faUsers,
} from '@fortawesome/free-solid-svg-icons';
import { useLocation } from 'react-router';
import ConflictStateRenderer from '@/components/server/ConflictStateRenderer';
import PermissionRoute from '@/components/elements/PermissionRoute';
import routes from '@/routers/routes';

const icons: Record<string, IconDefinition> = {
    Console: faTerminal,
    Files: faFolderOpen,
    Databases: faDatabase,
    Schedules: faClock,
    Users: faUsers,
    Backups: faCloudDownloadAlt,
    Network: faNetworkWired,
    Startup: faPlay,
    Settings: faCog,
    Activity: faEye,
};

const statusColor: Record<string, string> = {
    running: 'bg-green-400',
    starting: 'bg-yellow-400',
    stopping: 'bg-yellow-400',
    offline: 'bg-red-500',
};

export default () => {
    const match = useRouteMatch<{ id: string }>();
    const location = useLocation();

    const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);
    const [error, setError] = useState('');

    const id = ServerContext.useStoreState((state) => state.server.data?.id);
    const uuid = ServerContext.useStoreState((state) => state.server.data?.uuid);
    const inConflictState = ServerContext.useStoreState((state) => state.server.inConflictState);
    const serverId = ServerContext.useStoreState((state) => state.server.data?.internalId);
    const serverName = ServerContext.useStoreState((state) => state.server.data?.name);
    const serverNode = ServerContext.useStoreState((state) => state.server.data?.node);
    const powerState = ServerContext.useStoreState((state) => state.status.value);
    const allocation = ServerContext.useStoreState((state) =>
        state.server.data?.allocations.find((a) => a.isDefault)
    );
    const getServer = ServerContext.useStoreActions((actions) => actions.server.getServer);
    const clearServerState = ServerContext.useStoreActions((actions) => actions.clearServerState);

    const to = (value: string, url = false) => {
        if (value === '/') {
            return url ? match.url : match.path;
        }
        return `${(url ? match.url : match.path).replace(/\/*$/, '')}/${value.replace(/^\/+/, '')}`;
    };

    useEffect(
        () => () => {
            clearServerState();
        },
        []
    );

    useEffect(() => {
        setError('');

        getServer(match.params.id).catch((error) => {
            console.error(error);
            setError(httpErrorToHuman(error));
        });

        return () => {
            clearServerState();
        };
    }, [match.params.id]);

    const header = (
        <div className={'mb-2'}>
            <Link
                to={'/'}
                className={'flex items-center text-xs text-neutral-300 no-underline hover:text-sky-300 mb-3 px-1'}
            >
                <FontAwesomeIcon icon={faArrowLeft} className={'mr-2'} /> Dashboard
            </Link>
            <div className={'rounded-xl border border-neutral-600 bg-neutral-700 p-3'}>
                <div className={'flex items-center'}>
                    <span
                        className={`inline-block w-2.5 h-2.5 rounded-full mr-2 flex-none ${
                            statusColor[powerState || 'offline'] || 'bg-neutral-400'
                        }`}
                    />
                    <p className={'text-sm font-medium text-neutral-100 truncate'}>{serverName}</p>
                </div>
                <p className={'text-xs text-neutral-300 mt-1 truncate'}>{serverNode}</p>
                {allocation && (
                    <p className={'text-xs text-sky-300 mt-1 font-mono truncate'}>
                        {allocation.alias || allocation.ip}:{allocation.port}
                    </p>
                )}
            </div>
        </div>
    );

    const nav = (
        <>
            <SideHeading>Server</SideHeading>
            {routes.server
                .filter((route) => !!route.name)
                .map((route) =>
                    route.permission ? (
                        <Can key={route.path} action={route.permission} matchAny>
                            <SideLink
                                to={to(route.path, true)}
                                exact={route.exact}
                                label={route.name!}
                                icon={icons[route.name!] || faCog}
                            />
                        </Can>
                    ) : (
                        <SideLink
                            key={route.path}
                            to={to(route.path, true)}
                            exact={route.exact}
                            label={route.name!}
                            icon={icons[route.name!] || faCog}
                        />
                    )
                )}
            {rootAdmin && (
                <>
                    <SideHeading>Staff</SideHeading>
                    <SideLink to={`/admin/servers/view/${serverId}`} label={'Manage in Admin'} icon={faCogs} external />
                </>
            )}
        </>
    );

    return (
        <React.Fragment key={'server-router'}>
            <Shell header={uuid && id ? header : undefined} nav={uuid && id ? nav : undefined}>
                {!uuid || !id ? (
                    error ? (
                        <ServerError message={error} />
                    ) : (
                        <Spinner size={'large'} centered />
                    )
                ) : (
                    <>
                        <InstallListener />
                        <TransferListener />
                        <WebsocketHandler />
                        {inConflictState &&
                        (!rootAdmin || (rootAdmin && !location.pathname.endsWith(`/server/${id}`))) ? (
                            <ConflictStateRenderer />
                        ) : (
                            <ErrorBoundary>
                                <TransitionRouter>
                                    <Switch location={location}>
                                        {routes.server.map(({ path, permission, component: Component }) => (
                                            <PermissionRoute key={path} permission={permission} path={to(path)} exact>
                                                <Spinner.Suspense>
                                                    <Component />
                                                </Spinner.Suspense>
                                            </PermissionRoute>
                                        ))}
                                        <Route path={'*'} component={NotFound} />
                                    </Switch>
                                </TransitionRouter>
                            </ErrorBoundary>
                        )}
                    </>
                )}
            </Shell>
        </React.Fragment>
    );
};
