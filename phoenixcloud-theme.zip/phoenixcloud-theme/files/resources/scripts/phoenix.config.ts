// PhoenixCloud front-end settings. Edit, then run `yarn build:production`
// (or ask for a rebuilt zip). Leave a link's `url` empty to hide that card.
export default {
    // Dismissible banner shown on the dashboard and server console. Empty string = hidden.
    notice: {
        title: 'Important!',
        text: 'Always keep a backup of your server. Open the Backups section to create one.',
    },
    // Quick-link cards on the dashboard.
    links: [
        { title: 'Discord', blurb: 'Get help and talk to the community.', url: '' },
        { title: 'Website', blurb: 'Our main website.', url: 'https://phoenixcloud.bond' },
        { title: 'Contact support', blurb: 'Open a ticket with a human.', url: 'https://dash.phoenixcloud.bond' },
    ],
};
