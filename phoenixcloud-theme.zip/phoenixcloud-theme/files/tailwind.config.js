const colors = require('tailwindcss/colors');

// PhoenixCloud palette: deep navy surfaces + ice-blue accents.
const gray = {
    50: '#f0f7ff',
    100: '#e2effd',
    200: '#c9def5',
    300: '#9db6d4',
    400: '#7690b2',
    500: '#4a6286',
    600: '#233a60',
    700: '#112342',
    800: '#0a1630',
    900: '#060e22',
};

module.exports = {
    content: [
        './resources/scripts/**/*.{js,ts,tsx}',
    ],
    theme: {
        extend: {
            fontFamily: {
                header: ['"IBM Plex Sans"', '"Roboto"', 'system-ui', 'sans-serif'],
            },
            colors: {
                black: '#030713',
                // "primary" and "neutral" are deprecated, prefer the use of "blue" and "gray"
                // in new code.
                primary: colors.sky,
                blue: colors.sky,
                gray: gray,
                neutral: gray,
                cyan: colors.sky,
                sky: colors.sky,
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            transitionDuration: {
                250: '250ms',
            },
            borderColor: theme => ({
                default: theme('colors.neutral.400', 'currentColor'),
            }),
        },
    },
    plugins: [
        require('@tailwindcss/line-clamp'),
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ]
};
