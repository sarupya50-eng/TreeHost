# Anchor Macro (Fabric 1.21.11, client-side)

## What it does
1. Right-click respawn anchor with glowstone -> charges it (normal).
2. Right-click it again with glowstone -> mod switches to hotbar slot 9 and detonates the anchor.
3. You stay on slot 9 (put your totem / sword there).

Slot 9 must NOT contain glowstone.

## Build
Requires JDK 21 and Gradle 9.2+ installed.

    gradle wrapper
    ./gradlew build        (Windows: gradlew.bat build)

Jar: build/libs/anchor-macro-1.0.0.jar -> copy to .minecraft/mods/ along with Fabric API.

Alternative: open the folder in IntelliJ IDEA (it handles Gradle for you), then run the `build` task.
