package com.sayujya.anchormacro;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;

/**
 * Click 1 with glowstone on an empty anchor  -> charges it (vanilla, nothing special)
 * Click 2 with glowstone on a charged anchor -> switch to slot 9 and detonate it
 */
public class AnchorMacroClient implements ClientModInitializer {
    private static final int SLOT_9 = 8; // hotbar index 0-8
    private static boolean busy = false;

    @Override
    public void onInitializeClient() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!world.isClient() || busy || hand != Hand.MAIN_HAND) return ActionResult.PASS;
            if (!player.getMainHandStack().isOf(Items.GLOWSTONE)) return ActionResult.PASS;

            BlockState state = world.getBlockState(hit.getBlockPos());
            if (!state.isOf(Blocks.RESPAWN_ANCHOR)) return ActionResult.PASS;
            if (state.get(RespawnAnchorBlock.CHARGES) < 1) return ActionResult.PASS; // 1st click: let it charge

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.interactionManager == null || !(player instanceof ClientPlayerEntity cp)) return ActionResult.PASS;

            // If slot 9 also holds glowstone it would just charge again, so skip
            if (cp.getInventory().getStack(SLOT_9).isOf(Items.GLOWSTONE)) return ActionResult.PASS;

            // 2nd click: swap to slot 9 and right-click the charged anchor -> blast
            busy = true;
            try {
                cp.getInventory().setSelectedSlot(SLOT_9);
                mc.interactionManager.interactBlock(cp, Hand.MAIN_HAND, hit);
                cp.swingHand(Hand.MAIN_HAND);
            } finally {
                busy = false;
            }
            return ActionResult.FAIL; // cancel the original glowstone use
        });
    }
}
