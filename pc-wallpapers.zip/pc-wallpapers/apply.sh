#!/usr/bin/env bash
# PhoenixCloud wallpapers: purple on the login page, black after login.
# CSS + images only: no rebuild, no Node. Safe to run more than once.
set -euo pipefail
PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
W="$PANEL_DIR/resources/views/templates/wrapper.blade.php"

[[ -f "$PANEL_DIR/artisan" ]] || { echo "No Pterodactyl panel at $PANEL_DIR (set PANEL_DIR=...)"; exit 1; }
[[ -f "$W" ]] || { echo "Missing $W"; exit 1; }
[[ -f "$HERE/css/pc-wallpaper.css" && -f "$HERE/img/bg-login.jpg" && -f "$HERE/img/bg-app.jpg" ]] \
  || { echo "Files missing next to apply.sh. Re-unzip and run again."; exit 1; }

BK="$HOME/pc-wallpaper-backup-$(date -u +%Y%m%d-%H%M%S)"
mkdir -p "$BK"
cp -n "$W" "$BK/wrapper.blade.php"

T="$PANEL_DIR/public/themes/pterodactyl"
mkdir -p "$T/css" "$T/img"
cp "$HERE/css/pc-wallpaper.css" "$T/css/"
cp "$HERE/img/bg-login.jpg" "$HERE/img/bg-app.jpg" "$T/img/"

# add the stylesheet link once, then bump its cache-buster every run
if ! grep -q 'pc-wallpaper.css' "$W"; then
  sed -i "s#@yield('assets')#@yield('assets')\n        <link rel=\"stylesheet\" href=\"/themes/pterodactyl/css/pc-wallpaper.css?v=0\">#" "$W"
fi
grep -q 'pc-wallpaper.css' "$W" || { echo "Could not add the stylesheet link to $W. Nothing else changed."; exit 1; }
sed -i -E "s#(pc-wallpaper\.css\?v=)[0-9]+#\1$(date +%s)#" "$W"

OWN="$(stat -c '%U:%G' "$PANEL_DIR/storage" 2>/dev/null || true)"
[[ -n "$OWN" ]] && chown -R "$OWN" "$T" "$W" 2>/dev/null || echo "Note: could not chown; files may need your web user as owner."

( cd "$PANEL_DIR" && php artisan view:clear )
echo
echo "Done. Hard-refresh the browser (Ctrl+Shift+R)."
echo "Undo: cp $BK/wrapper.blade.php $W && rm -f $T/css/pc-wallpaper.css $T/img/bg-login.jpg $T/img/bg-app.jpg && (cd $PANEL_DIR && php artisan view:clear)"
