# PhoenixCloud wallpapers
Purple on the login page, black after login. CSS + images only, no rebuild.

    unzip pc-wallpapers.zip && cd pc-wallpapers && sudo bash apply.sh

Safe to re-run. Backup and undo command are printed at the end.
To swap a picture later: replace img/bg-login.jpg or img/bg-app.jpg and run apply.sh again.
